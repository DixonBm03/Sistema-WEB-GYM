document.addEventListener('DOMContentLoaded', async () => {
    const rutinaTable = document.querySelector('.table-container tbody');
    const form = document.querySelector('form');
    const inputs = form.querySelectorAll('input');
    const registrarButton = document.getElementById('guardar');
    const limpiarButton = document.getElementById('limpiar');
    const actualizarButton = document.getElementById('actualizar');
    const eliminarButton = document.getElementById('eliminar');
    const user = sessionStorage.getItem('user');

    let selectedRow = null;

    actualizarButton.disabled = true;
    eliminarButton.disabled = true;

    const cargarRutinas = async () => {
        try {
            const response = await fetch('/api/rutinas');
            const rutinas = await response.json();

            rutinaTable.innerHTML = '';

            rutinas.forEach(rutina => {
                const nuevaFila = document.createElement('tr');

                nuevaFila.innerHTML = `
                    <td>${rutina.id}</td>
                    <td data-cliente-id="${rutina.cliente.id}">${rutina.cliente.nombre}</td>
                    <td data-instructor-id="${rutina.instructor.id}">${rutina.instructor.nombre}</td>
                    <td data-maquina-id="${rutina.maquina.id}">${rutina.maquina.descripcion}</td>
                    <td>${rutina.fecha}</td>
                    <td>${rutina.horas}</td>
                `;
                nuevaFila.addEventListener('click', () => seleccionarFila(nuevaFila));
                rutinaTable.appendChild(nuevaFila);
            });
        } catch (error) {
            console.error('Error cargando rutinas:', error);
        }
    };

    const cargarSelects = async () => {
        try {
            const [clientesResponse, instructoresResponse, maquinasResponse] = await Promise.all([
                fetch('/api/clientes'),
                fetch('/api/instructores'),
                fetch('/api/maquinas'),
            ]);

            const clientes = await clientesResponse.json();
            const instructores = await instructoresResponse.json();
            const maquinas = await maquinasResponse.json();

            const clienteSelect = document.getElementById('cliente');
            const instructorSelect = document.getElementById('instructor');
            const maquinaSelect = document.getElementById('maquina');


            clientes.forEach(cliente => {
                const option = document.createElement('option');
                option.value = cliente.id;
                option.textContent = cliente.nombre;
                clienteSelect.appendChild(option);
            });

            instructores.forEach(instructor => {
                const option = document.createElement('option');
                option.value = instructor.id;
                option.textContent = instructor.nombre;
                instructorSelect.appendChild(option);
            });


            maquinas.forEach(maquina => {
                const option = document.createElement('option');
                option.value = maquina.id;
                option.textContent = maquina.descripcion;
                maquinaSelect.appendChild(option);
            });
        } catch (error) {
            console.error('Error cargando opciones:', error);
        }
    };

    cargarRutinas();
    cargarSelects();


    const mostrarMensaje = (mensaje) => {
        alert(mensaje);
    };

    form.addEventListener('submit', async (event) => {
        event.preventDefault();

        const clienteId = document.getElementById('cliente').value;
        const instructorId = document.getElementById('instructor').value;
        const maquinaId = document.getElementById('maquina').value;

        const rutinaData = {
            id: document.getElementById('id_rutina').value,
            cliente: {
                id: clienteId
            },
            instructor: {
                id: instructorId
            },
            maquina: {
                id: maquinaId
            },
            fecha: document.getElementById('fecha').value,
            horas: document.getElementById('horas').value
        };

        if (!rutinaData.id || !rutinaData.cliente.id || !rutinaData.instructor.id || !rutinaData.maquina.id || !rutinaData.fecha || !rutinaData.horas) {
            mostrarMensaje('Por favor, complete todos los campos requeridos.');
            return;
        }

        try {
            const response = await fetch(`/api/rutinas?ced=${encodeURIComponent(user)}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(rutinaData),
            });

            const message = await response.text();  // Obtiene el mensaje de la respuesta

            if (response.ok) {
                if (message === "Activo") {
                    mostrarMensaje('Rutina registrada correctamente.');
                    cargarRutinas();
                    limpiarCampos();
                } else {
                    mostrarMensaje('Error: el cliente está inactivo.');
                }
            } else {
                if (message === "inactivo") {
                    mostrarMensaje('Error: la membresía del cliente está inactiva.');
                } else {
                    mostrarMensaje(`Error: ${message}`);
                }
            }
        } catch (error) {
            console.error('Error registrando rutina:', error);
        }
    });


    const seleccionarFila = (fila) => {
        if (selectedRow) {
            selectedRow.classList.remove('selected');
        }
        selectedRow = fila;
        selectedRow.classList.add('selected');

        const celdas = selectedRow.querySelectorAll('td');

        const clienteId = celdas[1].getAttribute('data-cliente-id');
        const instructorId = celdas[2].getAttribute('data-instructor-id');
        const maquinaId = celdas[3].getAttribute('data-maquina-id');

        document.getElementById('id_rutina').value = celdas[0].textContent;
        document.getElementById('cliente').value = clienteId;
        document.getElementById('instructor').value = instructorId;
        document.getElementById('maquina').value = maquinaId;
        document.getElementById('fecha').value = celdas[4].textContent;
        document.getElementById('horas').value = celdas[5].textContent;

        actualizarButton.disabled = false;
        eliminarButton.disabled = false;
        registrarButton.disabled = true;
    };

    const limpiarCampos = () => {
        const campos = form.querySelectorAll('input, select');

        campos.forEach(campo => {
            campo.value = '';
            campo.disabled = false;
        });

        document.getElementById('fecha').disabled = false;
        document.getElementById('horas').disabled = false;

        actualizarButton.disabled = true;
        eliminarButton.disabled = true;
        registrarButton.disabled = false;
    };

    actualizarButton.addEventListener('click', async () => {
        if (selectedRow) {
            const idRutina = document.getElementById('id_rutina').value;


            const rutinaData = {
                id: idRutina,
                cliente: {
                    id: document.getElementById('cliente').value
                },
                instructor: {
                    id: document.getElementById('instructor').value
                },
                maquina: {
                    id: document.getElementById('maquina').value
                },
                fecha: document.getElementById('fecha').value,
                horas: document.getElementById('horas').value
            };

            if (!rutinaData.cliente.id || !rutinaData.instructor.id || !rutinaData.maquina.id || !rutinaData.fecha || !rutinaData.horas) {
                mostrarMensaje('Por favor, complete todos los campos antes de actualizar.');
                return;
            }

            try {
                const response = await fetch(`/api/rutinas/actualizar/${idRutina}?ced=${encodeURIComponent(user)}`, {
                    method: 'PUT',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify(rutinaData),
                });

                if (response.ok) {
                    mostrarMensaje('Rutina actualizada correctamente.');
                    cargarRutinas();
                    limpiarCampos();
                } else {
                    mostrarMensaje('Error: No se puede actualizar porque estas intentando actualizar una llave primaria o foranea');
                }
            } catch (error) {
                console.error('Error al actualizar la rutina:', error);
            }
        }
    });

    eliminarButton.addEventListener('click', async () => {
        if (selectedRow) {
            const idRutina = document.getElementById('id_rutina').value;

            if (confirm('¿Está seguro de que desea eliminar esta rutina?')) {
                try {
                    const response = await fetch(`/api/rutinas/eliminar/${idRutina}?ced=${encodeURIComponent(user)}`, {
                        method: 'DELETE',
                    });

                    if (response.ok) {
                        mostrarMensaje('Rutina eliminada correctamente.');
                        cargarRutinas();
                        limpiarCampos();
                    } else {
                        mostrarMensaje('Error al eliminar la rutina.');
                    }
                } catch (error) {
                    console.error('Error eliminando rutina:', error);
                }
            }
        }
    });

    limpiarButton.addEventListener('click', () => {
        limpiarCampos();
    });
});
