document.addEventListener("DOMContentLoaded", () => {
    // Obtener el ID del cliente desde sessionStorage
    const clienteId = sessionStorage.getItem('user');

    if (!clienteId) {
        alert("ID de cliente no encontrado.");
        return;
    }

    // Hacer la solicitud para obtener el historial de cursos del cliente (suponiendo que el backend usa este ID)
    fetch(`http://localhost:8080/api/historialCursos/cliente/${clienteId}`)
        .then(response => {
            if (!response.ok) {
                throw new Error('Error al obtener los cursos del cliente');
            }
            return response.json();
        })
        .then(historial => {
            const tbody = document.getElementById('historial-tbody');
            tbody.innerHTML = ''; // Limpiar la tabla antes de llenarla

            if (!Array.isArray(historial) || historial.length === 0) {
                tbody.innerHTML = '<tr><td colspan="6">No se encontraron cursos</td></tr>';
                return;
            }

            historial.forEach(curso => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${curso.id}</td>
                    <td>${curso.cliente.nombre}</td>
                    <td>${curso.instructor.nombre}</td>
                    <td>${curso.curso.descripcion}</td>
                    <td>${new Date(curso.fecha).toLocaleDateString("es-ES")}</td>
                    <td>${curso.horas}</td>
                `;
                tbody.appendChild(row);
            });
        })
        .catch(error => {
            console.error("Error:", error);
            alert("Hubo un error al cargar los cursos.");
        });
});
