function adjustMenuForUser() {
    const userRole = sessionStorage.getItem('userRole');
    const logoutButton = document.getElementById('logoutButton');
    const misRutinasButton = document.getElementById('misRutinasButton');
    const misCursosButton = document.getElementById('misCursosButton');
    const desin=document.getElementById('desin');
    const user = sessionStorage.getItem('user');

    if (logoutButton) {
        logoutButton.style.display = 'inline-block';
    }

    const buttons = document.querySelectorAll('button');

    if (!buttons || buttons.length === 0) {
        console.error('No se encontraron botones en la página');
        return;
    }

    buttons.forEach(button => {
        if (button !== logoutButton) {
            button.style.display = 'none';
        }
    });

    if (userRole === 'Soporte') {

        buttons.forEach(button => button.style.display = 'inline-block');

        // if (misRutinasButton) misRutinasButton.style.display = 'none';
        // if (misCursosButton) misCursosButton.style.display = 'none';
        if (desin) desin.style.display = 'none';

    } else if (userRole === 'Instructor') {
        const allowed = [
            '../instructor/view.html',
            '../clientes/view.html',
            '../cursos/view.html',
            '../maquinas/view.html',
            '../rutinas/view.html',
            '../historialCursos/view.html',
            '../membresia/view.html'
        ];

        buttons.forEach(button => {
            if (allowed.some(route => button.getAttribute('onclick').includes(route))) {
                button.style.display = 'inline-block';
            }
        });
    } else if (userRole === 'Cliente') {
        const allowed = [
            '../rutinasDeClientes/view.html',
            '../historialCursosDeCliente/view.html',
            'http://localhost:8080/'
        ];

        buttons.forEach(button => {
            if (allowed.some(route => button.getAttribute('onclick').includes(route))) {
                button.style.display = 'inline-block';
            }
        });
    }

    desin.addEventListener("click", async() => {
        if (confirm('¿Está seguro de que desea desinscribirse?')) {
            try {
                const response = await fetch(`/api/clientes/desin?ced=${encodeURIComponent(user)}`, { method: 'DELETE' });
                if (response.ok) {
                    window.location.href='http://localhost:8080/';
                    mostrarMensaje('Cliente desinscrito correctamente.');
                } else {
                    mostrarMensaje('Error: No se pudo desinscribir.');
                }
            } catch (error) {
                console.error('Error al eliminar cliente:', error);
            }
        }
    });
}

document.addEventListener('DOMContentLoaded', function() {
    console.log("DOM completamente cargado y procesado");
    if (window.location.pathname.includes('principal/view.html')) {
        adjustMenuForUser();
    }
});
