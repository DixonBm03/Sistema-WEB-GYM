document.addEventListener('DOMContentLoaded', () => {
    const instructorTable = document.querySelector('.instructor-table-container tbody');
    const form = document.querySelector('form');
    const inputs = form.querySelectorAll('input');
    const registrarButton = document.getElementById('guardar');
    const limpiarButton = document.getElementById('limpiar');
    const actualizarButton = document.getElementById('actualizar');
    const eliminarButton = document.getElementById('eliminar');
    const user = sessionStorage.getItem('user');

    let selectedRow = null;

    actualizarButton.disabled = true;
    eliminarButton.disabled = true;

    const cargarInstructores = async () => {
        try {
            const response = await fetch('/api/instructores');
            const instructores = await response.json();
            instructores.forEach(instructor => {
                agregarFilaATabla(instructor);
            });
        } catch (error) {
            console.error('Error al cargar instructores:', error);
        }
    };

    const agregarFilaATabla = (instructor) => {
        console.log(instructor);
        const nuevaFila = document.createElement('tr');
        nuevaFila.innerHTML = `
        <td>${instructor.id}</td>
        <td>${instructor.nombre}</td>
        <td>${instructor.apellido1}</td>
        <td>${instructor.apellido2}</td>
        <td>${instructor.direccion}</td>
        <td>${instructor.email}</td>
        <td>${instructor.celular}</td>
        <td>${instructor.telHabitacion}</td>
        <td>${instructor.fechaContratacion}</td>
    `;
        nuevaFila.addEventListener('click', () => seleccionarFila(nuevaFila));
        instructorTable.appendChild(nuevaFila);
    };

    const limpiarCampos = () => {
        inputs.forEach(input => {
            input.value = '';
            input.disabled = false;
        });
        actualizarButton.disabled = true;
        eliminarButton.disabled = true;
        registrarButton.disabled = false;
    };


    const mostrarMensaje = (mensaje) => {
        alert(mensaje);
    };


    form.addEventListener('submit', async (event) => {
        event.preventDefault();
        const instructorData = Array.from(inputs).reduce((data, input) => {
            data[input.id] = input.value;
            return data;
        }, {});


        if (!instructorData.nombre || !instructorData.celular || !instructorData.apellido1) {
            mostrarMensaje('Por favor, complete todos los campos requeridos.');
            return;
        }

        try {
            const response = await fetch(`/api/instructores?ced=${encodeURIComponent(user)}`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(instructorData)
            });

            if (response.ok) {
                const nuevoInstructor = await response.json();
                agregarFilaATabla(nuevoInstructor);
                mostrarMensaje('Instructor registrado correctamente.');
                limpiarCampos();
            } else if (response.status === 409) {
                mostrarMensaje('Instructor ya existe.');
            } else {
                mostrarMensaje('Error al registrar el instructor.');
            }
        } catch (error) {
            console.error('Error al registrar instructor:', error);
        }
    });

    const seleccionarFila = (fila) => {
        if (selectedRow) {
            selectedRow.classList.remove('selected');
        }
        selectedRow = fila;
        selectedRow.classList.add('selected');

        const celdas = selectedRow.querySelectorAll('td');
        document.getElementById('id').value = celdas[0].textContent;
        document.getElementById('nombre').value = celdas[1].textContent;
        document.getElementById('apellido1').value = celdas[2].textContent;
        document.getElementById('apellido2').value = celdas[3].textContent;
        document.getElementById('direccion').value = celdas[4].textContent;
        document.getElementById('email').value = celdas[5].textContent;
        document.getElementById('celular').value = celdas[6].textContent;
        document.getElementById('telHabitacion').value = celdas[7].textContent;
        document.getElementById('fechaContratacion').value = celdas[8].textContent;

        actualizarButton.disabled = false;
        eliminarButton.disabled = false;
        registrarButton.disabled = true;
    };

    actualizarButton.addEventListener('click', async () => {
        if (selectedRow) {
            const id = document.getElementById('id').value;
            const instructorData = Array.from(inputs).reduce((data, input) => {
                data[input.id] = input.value;
                return data;
            }, {});

            try {
                const response = await fetch(`/api/instructores/${id}?ced=${encodeURIComponent(user)}`, {
                    method: 'PUT',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(instructorData)
                });

                if (response.ok) {
                    const celdas = selectedRow.querySelectorAll('td');
                    celdas[1].textContent = instructorData.nombre;
                    celdas[2].textContent = instructorData.apellido1;
                    celdas[3].textContent = instructorData.apellido2;
                    celdas[4].textContent = instructorData.direccion;
                    celdas[5].textContent = instructorData.email;
                    celdas[6].textContent = instructorData.celular;
                    celdas[7].textContent = instructorData.telHabitacion;
                    celdas[8].textContent = instructorData.fechaContratacion;

                    mostrarMensaje('Instructor actualizado correctamente.');
                    limpiarCampos();
                } else {
                    mostrarMensaje('Error: No se puede actualizar porque estas intentando actualizar una llave primaria.');
                }
            } catch (error) {
                console.error('Error al actualizar instructor:', error);
            }
        }
    });

    eliminarButton.addEventListener('click', async () => {
        if (selectedRow) {
            const id = document.getElementById('id').value;
            if (confirm('¿Está seguro de que desea eliminar este instructor?')) {
                try {
                    const response = await fetch(`/api/instructores/${id}?ced=${encodeURIComponent(user)}`, { method: 'DELETE' });
                    if (response.ok) {
                        selectedRow.remove();
                        mostrarMensaje('Instructor eliminado correctamente.');
                        limpiarCampos();
                    } else {
                        mostrarMensaje('Error: No se puede eliminar porque esta ligado a un registro de otra tabla.');
                    }
                } catch (error) {
                    console.error('Error al eliminar instructor:', error);
                }
            }
        }
    });

    limpiarButton.addEventListener('click', () => {
        limpiarCampos();
    });

    cargarInstructores();
});
