async function cargarMaquinas() {
    try {
        const response = await fetch('http://localhost:8080/api/maquinas');
        if (!response.ok) {
            throw new Error(`Error al obtener los datos: ${response.statusText}`);
        }
        const maquinas = await response.json();
        console.log('Datos recibidos:', maquinas);
        const tbody = document.querySelector('table tbody');
        tbody.innerHTML = '';
        maquinas.forEach(maquina => {
            console.log('Maquina:', maquina);
            const fila = document.createElement('tr');
            fila.innerHTML = `
                <td>${maquina.id || 'N/A'}</td>
                <td>${maquina.descripcion || 'N/A'}</td>
                <td>${maquina.estado || 'N/A'}</td>
            `;
            fila.addEventListener('click', () => seleccionarFila(fila));
            tbody.appendChild(fila);
        });
    } catch (error) {
        console.error('Error cargando las máquinas:', error);
    }
}
window.onload = cargarMaquinas;
