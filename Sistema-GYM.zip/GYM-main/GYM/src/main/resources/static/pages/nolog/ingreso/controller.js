document.addEventListener("DOMContentLoaded", () => {
    const form = document.querySelector("form");

    form.addEventListener("submit", async (event) => {
        event.preventDefault();

        const id = document.getElementById("username").value;
        const password = document.getElementById("password").value;

        try {
            const response = await fetch(`/api/clientes/login?cedula=${encodeURIComponent(id)}&password=${encodeURIComponent(password)}`, {
                method: "POST"
            });

            if (response.status === 200) {
                const rol = await response.text();
                sessionStorage.setItem('userRole', rol);
                sessionStorage.setItem('user', id);
                window.location.href = '../../log/principal/view.html';
            } else {
                alert("Credenciales incorrectas o usuario no encontrado.");
            }
        } catch (error) {
            console.error("Error:", error);
            alert("Error al conectar con el servidor.");
        }
    });
});
