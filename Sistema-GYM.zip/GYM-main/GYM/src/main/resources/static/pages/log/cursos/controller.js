document.addEventListener('DOMContentLoaded', () => {
    const cursoTable = document.querySelector('.table-container tbody');
    const form = document.querySelector('form');
    const inputs = form.querySelectorAll('input');
    const registrarButton = document.getElementById('guardar');
    const limpiarButton = document.getElementById('limpiar');
    const actualizarButton = document.getElementById('actualizar');
    const eliminarButton = document.getElementById('eliminar');
    const user = sessionStorage.getItem('user');

    let selectedRow = null;

    actualizarButton.disabled = true;
    eliminarButton.disabled = true;

    const cargarCursos = async () => {
        try {
            const response = await fetch('/api/cursos');
            const cursos = await response.json();

            cursos.forEach(curso => {
                const nuevaFila = document.createElement('tr');
                nuevaFila.innerHTML = `
                    <td>${curso.id}</td>
                    <td>${curso.descripcion}</td>
                    <td>${curso.horarios}</td>
                `;
                nuevaFila.addEventListener('click', () => seleccionarFila(nuevaFila));
                cursoTable.appendChild(nuevaFila);
            });
        } catch (error) {
            mostrarMensaje('Error al cargar los cursos.');
        }
    };

    cargarCursos();

    const limpiarCampos = () => {
        inputs.forEach(input => {
            input.value = '';
            input.disabled = false;
        });
        actualizarButton.disabled = true;
        eliminarButton.disabled = true;
        registrarButton.disabled = false;
    };

    const mostrarMensaje = (mensaje) => {
        alert(mensaje);
    };

    form.addEventListener('submit', async (event) => {
        event.preventDefault();

        const cursoData = Array.from(inputs).reduce((data, input) => {
            data[input.id] = input.value;
            return data;
        }, {});

        if (!cursoData.id_curso || !cursoData.descripcion || !cursoData.horarios) {
            mostrarMensaje('No se pudo agregar. Por favor, complete todos los campos requeridos.');
            return;
        }

        try {
            const response = await fetch(`/api/cursos?ced=${encodeURIComponent(user)}`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    id: cursoData.id_curso,
                    descripcion: cursoData.descripcion,
                    horarios: cursoData.horarios
                })
            });

            if (response.ok) {
                window.location.reload();
                mostrarMensaje('Curso registrado correctamente.');
                limpiarCampos();
            } else {
                mostrarMensaje('El curso ya existe!!!.');
            }
        } catch (error) {
            mostrarMensaje('Error en la solicitud al registrar el curso.');
        }
    });


    const seleccionarFila = (fila) => {
        if (selectedRow) {
            selectedRow.classList.remove('selected');
        }
        selectedRow = fila;
        selectedRow.classList.add('selected');

        // Rellenar campos de texto con los datos de la fila seleccionada
        const celdas = selectedRow.querySelectorAll('td');

        document.getElementById('id_curso').value = celdas[0].textContent;
        document.getElementById('descripcion').value = celdas[1].textContent;
        document.getElementById('horarios').value = celdas[2].textContent;

        actualizarButton.disabled = false;
        eliminarButton.disabled = false;
        registrarButton.disabled = true;
    };


    actualizarButton.addEventListener('click', async () => {
        if (selectedRow) {
            const cursoId = document.getElementById('id_curso').value;

            const cursoActualizado = {
                descripcion: document.getElementById('descripcion').value,
                horarios: document.getElementById('horarios').value
            };

            try {
                const response = await fetch(`/api/cursos/${cursoId}?ced=${encodeURIComponent(user)}`, {
                    method: 'PUT',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(cursoActualizado)
                });

                if (response.ok) {
                    const celdas = selectedRow.querySelectorAll('td');
                    celdas[1].textContent = cursoActualizado.descripcion;
                    celdas[2].textContent = cursoActualizado.horarios;
                    mostrarMensaje('Curso actualizado correctamente.');
                    limpiarCampos();
                } else {
                    mostrarMensaje('Error: No se puede actualizar porque estas intentando actualizar una llave primaria.');
                }
            } catch (error) {
                mostrarMensaje('Error en la solicitud al actualizar el curso.');
            }
        } else {
            mostrarMensaje('No se pudo actualizar.');
        }
    });

    eliminarButton.addEventListener('click', async () => {
        if (selectedRow) {
            const cursoId = document.getElementById('id_curso').value;

            if (confirm('¿Está seguro de que desea eliminar este curso?')) {
                try {
                    const response = await fetch(`/api/cursos/${cursoId}?ced=${encodeURIComponent(user)}`, {
                        method: 'DELETE'
                    });

                    if (response.ok) {
                        selectedRow.remove();
                        mostrarMensaje('Curso eliminado correctamente.');
                        limpiarCampos();
                    } else {
                        mostrarMensaje('Error: No se puede eliminar porque esta ligado a un registro de otra tabla.');
                    }
                } catch (error) {
                    mostrarMensaje('Error en la solicitud al eliminar el curso.');
                }
            }
        } else {
            mostrarMensaje('No se pudo eliminar.');
        }
    });

    limpiarButton.addEventListener('click', () => {
        limpiarCampos();
    });
});
