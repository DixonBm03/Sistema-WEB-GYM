// controller.js

document.addEventListener("DOMContentLoaded", () => {
    // Obtener el ID del usuario desde sessionStorage
    const userId = sessionStorage.getItem('user');


    if (!userId) {
        alert("ID de usuario no encontrado.");
        return;
    }

    // Hacer la solicitud para obtener las rutinas del usuario (suponiendo que el backend usa este ID)
    fetch(`http://localhost:8080/api/rutinas/cliente/${userId}`)
        .then(response => {
            if (!response.ok) {
                throw new Error('Error al obtener las rutinas');
            }
            return response.json();
        })
        .then(rutinas => {
            const tbody = document.getElementById('rutinas-tbody');
            tbody.innerHTML = ''; // Limpiar la tabla antes de llenarla

            if (!Array.isArray(rutinas) || rutinas.length === 0) {
                tbody.innerHTML = '<tr><td colspan="6">No se encontraron rutinas</td></tr>';
                return;
            }

            rutinas.forEach(rutina => {
                const row = document.createElement('tr');
                row.innerHTML = `
            <td>${rutina.id}</td>
            <td>${rutina.cliente.nombre}</td>
            <td>${rutina.instructor.nombre}</td>
            <td>${rutina.maquina.descripcion}</td>
            <td>${new Date(rutina.fecha).toLocaleDateString("es-ES")}</td>
            <td>${rutina.horas}</td>
        `;
                tbody.appendChild(row);
            });
        })
        .catch(error => {
            console.error("Error:", error);
            alert("Hubo un error al cargar las rutinas.");
        });
});
