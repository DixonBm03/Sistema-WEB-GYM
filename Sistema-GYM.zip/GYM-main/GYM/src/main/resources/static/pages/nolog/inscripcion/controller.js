document.addEventListener("DOMContentLoaded", () => {

    const form = document.querySelector("form");
    const limpiarBtn = document.getElementById("limpiar");

    form.addEventListener("submit", async (event) => {
        event.preventDefault();
        const clienteData = {
            id: document.getElementById("ced_cliente").value,
            nombre: document.getElementById("nombre").value,
            apellido1: document.getElementById("apellido_1").value,
            apellido2: document.getElementById("apellido_2").value,
            direccion: document.getElementById("direccion").value,
            eMail: document.getElementById("e_mail").value,
            celular: document.getElementById("celular").value,
            telHabitacion: document.getElementById("tel_habitacion").value,
            fechaInscripcion: document.getElementById("fecha_inscripcion").value
        };
        const password = document.getElementById("password").value;

        try {
            const response = await fetch(`/api/clientes/registrarse?password=${encodeURIComponent(password)}`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(clienteData)
            });

            if (response.status === 201) {
                alert("Cliente registrado correctamente.");
                form.reset();
            } else if (response.status === 409) {
                alert("El cliente ya está registrado en el sistema.");
            } else {
                alert("Ocurrió un error al registrar el cliente.");
            }
        } catch (error) {
            console.error("Error:", error);
            alert("Error al conectar con el servidor.");
        }

    });
    limpiarBtn.addEventListener("click", () => {
        form.reset();
    });
});
