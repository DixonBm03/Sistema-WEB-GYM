document.addEventListener('DOMContentLoaded', async () => {
    const historialTable = document.querySelector('#historial-tbody');
    const form = document.querySelector('#historial-form');
    const clienteSelect = document.getElementById('cliente');
    const instructorSelect = document.getElementById('instructor');
    const cursoSelect = document.getElementById('curso');
    const registrarButton = document.getElementById('guardar');
    const limpiarButton = document.getElementById('limpiar');
    const actualizarButton = document.getElementById('actualizar');
    const eliminarButton = document.getElementById('eliminar');
    const user = sessionStorage.getItem('user');
    let clientes = [];
    let instructores = [];
    let cursos = [];

    let selectedRow = null;


    actualizarButton.disabled = true;
    eliminarButton.disabled = true;

    const cargarSelectClientes = async () => {
        try {
            const response = await fetch('/api/clientes');
            clientes = await response.json();
            clientes.forEach(cliente => {
                const option = document.createElement('option');
                option.value = cliente.id;
                option.textContent = `${cliente.nombre} (${cliente.id})`;
                clienteSelect.appendChild(option);
            });
        } catch (error) {
            console.error('Error cargando clientes:', error);
        }
    };

    const cargarSelectInstructores = async () => {
        try {
            const response = await fetch('/api/instructores');
            instructores = await response.json();
            instructores.forEach(instructor => {
                const option = document.createElement('option');
                option.value = instructor.id;
                option.textContent = `${instructor.nombre} (${instructor.id})`;
                instructorSelect.appendChild(option);
            });
        } catch (error) {
            console.error('Error cargando instructores:', error);
        }
    };

    const cargarSelectCursos = async () => {
        try {
            const response = await fetch('/api/cursos');
            cursos = await response.json();
            cursos.forEach(curso => {
                const option = document.createElement('option');
                option.value = curso.id;
                option.textContent = `${curso.descripcion} (${curso.id})`;
                cursoSelect.appendChild(option);
            });
        } catch (error) {
            console.error('Error cargando cursos:', error);
        }
    };

    cargarSelectClientes();
    cargarSelectInstructores();
    cargarSelectCursos();

    const cargarHistorialCursos = async () => {
        try {
            const response = await fetch('/api/historialCursos');
            const historialCursos = await response.json();
            historialTable.innerHTML = '';
            historialCursos.forEach(historial => agregarFila(historial));
        } catch (error) {
            console.error('Error cargando historial de cursos:', error);
        }
    };

    const agregarFila = (historial) => {
        const nuevaFila = document.createElement('tr');
        nuevaFila.innerHTML = `
        <td>${historial.id}</td>
        <td>${historial.cliente.nombre}</td>  
        <td>${historial.instructor.nombre}</td> 
        <td>${historial.curso.descripcion}</td> 
        <td>${historial.fecha}</td>
        <td>${historial.horas}</td>
    `;
        nuevaFila.addEventListener('click', () => seleccionarFila(nuevaFila));
        historialTable.appendChild(nuevaFila);
    };

    const seleccionarFila = (fila) => {
        if (selectedRow) selectedRow.classList.remove('selected');
        selectedRow = fila;
        selectedRow.classList.add('selected');

        const celdas = selectedRow.querySelectorAll('td');
        document.getElementById('id_historial').value = celdas[0].textContent;

        clienteSelect.value = clientes.find(cliente => cliente.nombre === celdas[1].textContent).id;
        instructorSelect.value = instructores.find(instructor => instructor.nombre === celdas[2].textContent).id;
        cursoSelect.value = cursos.find(curso => curso.descripcion === celdas[3].textContent).id;

        document.getElementById('fecha').value = celdas[4].textContent;
        document.getElementById('horas').value = celdas[5].textContent;

        registrarButton.disabled = true;
        actualizarButton.disabled = false;
        eliminarButton.disabled = false;
    };



    const limpiarCampos = () => {
        form.reset();
        selectedRow = null;
        registrarButton.disabled = false;
        actualizarButton.disabled = true;
        eliminarButton.disabled = true;
    };

    form.addEventListener('submit', async (event) => {
        event.preventDefault();
        const historialData = {
            id: document.getElementById('id_historial').value,
            cliente: { id: clienteSelect.value },
            instructor: { id: instructorSelect.value },
            curso: { id: cursoSelect.value },
            fecha: document.getElementById('fecha').value,
            horas: document.getElementById('horas').value
        };
        try {
            const response = await fetch(`/api/historialCursos?ced=${encodeURIComponent(user)}`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(historialData)
            });

            if (response.ok) {
                const message = await response.text();
                if (message === 'activo') {
                    alert('Historial registrado correctamente.');
                    cargarHistorialCursos();
                    limpiarCampos();
                }
            } else {
                const message = await response.text();
                if (message === 'inactivo') {
                    alert('Error: el cliente está inactivo.');
                } else {
                    alert('Error: el historial ya existe o el cliente, instructor, curso no existen en sus respectivas tablas.');
                }
            }
        } catch (error) {
            console.error('Error al registrar historial de curso:', error);
        }
    });

    actualizarButton.addEventListener('click', async () => {
        if (!selectedRow) return;

        const id = document.getElementById('id_historial').value;
        const historialData = {
            id: id, // Incluimos el ID del historial aquí
            cliente: { id: clienteSelect.value },
            instructor: { id: instructorSelect.value },
            curso: { id: cursoSelect.value },
            fecha: document.getElementById('fecha').value,
            horas: document.getElementById('horas').value
        };

        try {
            const response = await fetch(`/api/historialCursos/${id}ced=${encodeURIComponent(user)}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(historialData)
            });
            if (response.ok) {
                alert('Historial actualizado correctamente.');
                cargarHistorialCursos();
                limpiarCampos();
            }else {
                alert('Error: No se puede actualizar porque estas intentando actualizar una llave primaria o foranea.');
            }
        } catch (error) {
            console.error('Error al actualizar historial de curso:', error);
        }
    });


    eliminarButton.addEventListener('click', async () => {
        if (!selectedRow) return;
        const id = document.getElementById('id_historial').value;
        if (confirm('¿Está seguro de que desea eliminar este historial?')) {
            try {
                const response = await fetch(`/api/historialCursos/${id}?ced=${encodeURIComponent(user)}`, { method: 'DELETE' });

                if (response.ok) {
                    alert('Historial eliminado correctamente.');
                    cargarHistorialCursos();
                    limpiarCampos();
                } else {
                    alert('Error: No se pudo eliminar el historial.');
                }
            } catch (error) {
                console.error('Error al eliminar historial de curso:', error);
            }
        }
    });


    limpiarButton.addEventListener('click', limpiarCampos);

    cargarHistorialCursos();
});
