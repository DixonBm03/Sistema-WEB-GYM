document.addEventListener('DOMContentLoaded', () => {
    const instructorTable = document.querySelector('.instructor-table-container tbody');

    const cargarInstructores = async () => {
        try {
            const response = await fetch('/api/instructores');
            const instructores = await response.json();
            instructores.forEach(instructor => {
                agregarFilaATabla(instructor);
            });
        } catch (error) {
            console.error('Error al cargar instructores:', error);
        }
    };

    const agregarFilaATabla = (instructor) => {
        console.log(instructor);
        const nuevaFila = document.createElement('tr');
        nuevaFila.innerHTML = `
        <td>${instructor.id}</td>
        <td>${instructor.nombre}</td>
        <td>${instructor.apellido1}</td>
        <td>${instructor.apellido2}</td>
        <td>${instructor.fechaContratacion}</td>
    `;
        nuevaFila.addEventListener('click', () => seleccionarFila(nuevaFila));
        instructorTable.appendChild(nuevaFila);
    };

    cargarInstructores();
});
