document.addEventListener('DOMContentLoaded', () => {
    const cursoTable = document.querySelector('.table-container tbody');

    const cargarCursos = async () => {
        try {
            const response = await fetch('/api/cursos');
            const cursos = await response.json();
            cursos.forEach(curso => {
                agregarFilaATabla(curso);
            });
        } catch (error) {
            console.error('Error al cargar cursos:', error);
        }
    };

    const agregarFilaATabla = (curso) => {
        const nuevaFila = document.createElement('tr');
        nuevaFila.innerHTML = `
        <td>${curso.id}</td>
        <td>${curso.descripcion}</td>
        <td>${curso.horarios}</td>
    `;
        cursoTable.appendChild(nuevaFila);
    };

    cargarCursos();
});
