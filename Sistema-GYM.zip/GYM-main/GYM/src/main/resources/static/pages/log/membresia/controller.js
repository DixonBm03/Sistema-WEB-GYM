document.addEventListener('DOMContentLoaded', () => {
    const membresiaTable = document.querySelector('.table-container tbody');
    const form = document.querySelector('form');
    const inputs = form.querySelectorAll('input, select'); // Asegúrate de incluir los select
    const registrarButton = document.getElementById('guardar');
    const limpiarButton = document.getElementById('limpiar');
    const actualizarButton = document.getElementById('actualizar');
    const eliminarButton = document.getElementById('eliminar');
    const estadoSelect = document.getElementById('estado');
    const clienteSelect = document.getElementById('cliente'); // Obtenemos el select de clientes
    const user = sessionStorage.getItem('user');

    let selectedRow = null;

    actualizarButton.disabled = true;
    eliminarButton.disabled = true;

    const limpiarCampos = () => {
        inputs.forEach(input => {
            input.value = '';
            input.disabled = false;
        });
        estadoSelect.value = '';
        clienteSelect.value = ''; // Limpiar el select de clientes
        actualizarButton.disabled = true;
        eliminarButton.disabled = true;
        registrarButton.disabled = false;
    };

    const mostrarMensaje = (mensaje) => {
        alert(mensaje);
    };

    const cargarClientes = () => {
        fetch('/api/clientes') // Asegúrate de que esta URL sea correcta
            .then(response => {
                if (!response.ok) {
                    throw new Error('Error en la red: ' + response.statusText);
                }
                return response.json();
            })
            .then(data => {
                data.forEach(cliente => {
                    const option = document.createElement('option');
                    option.value = cliente.id; // Asegúrate de que 'id' sea la propiedad correcta
                    option.textContent = `${cliente.nombre} (${cliente.id})`; // Asegúrate de que 'nombre' sea la propiedad correcta
                    clienteSelect.appendChild(option);
                });
            })
            .catch(error => {
                mostrarMensaje('Error al cargar los clientes: ' + error);
            });
    };

    const cargarMembresias = async () => {
        try {
            const response = await fetch('/api/membresias');
            if (!response.ok) {
                throw new Error('Error en la red: ' + response.statusText);
            }
            const data = await response.json();
            data.forEach(membresia => {
                const nuevaFila = document.createElement('tr');
                nuevaFila.innerHTML = `
    <td>${membresia.id}</td>
    <td>${membresia.cliente ? membresia.cliente.id : 'N/A'}</td>
    <td>${membresia.tipo}</td>
    <td>${membresia.fechaInicio}</td>
    <td>${membresia.fechaFin}</td>
    <td>${membresia.estado}</td>
    <td>${membresia.monto}</td>
`;
                nuevaFila.addEventListener('click', () => seleccionarFila(nuevaFila));
                membresiaTable.appendChild(nuevaFila);
            });
        } catch (error) {
            console.error('Error al cargar las membresías:', error);
            mostrarMensaje('Error al cargar las membresías: ' + error.message);
        }
    };

    cargarClientes();
    cargarMembresias();

    form.addEventListener('submit', (event) => {
        event.preventDefault();

        const membresiaData = Array.from(inputs).reduce((data, input) => {
            data[input.id] = input.value;
            return data;
        }, {});

        membresiaData['estado'] = estadoSelect.value;
        membresiaData['cliente'] = { id: clienteSelect.value };

        // Validar que todos los campos requeridos estén llenos
        if (!membresiaData.id || !membresiaData.tipo || !membresiaData.fechaInicio || !membresiaData.fechaFin || !membresiaData.estado || !membresiaData.monto || !membresiaData.cliente) {
            mostrarMensaje('No se pudo agregar. Por favor, complete todos los campos requeridos.');
            return;
        }

        // Enviar datos al backend usando POST
        fetch(`/api/membresias?ced=${encodeURIComponent(user)}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(membresiaData)
        })
            .then(response => response.json())
            .then(data => {
                window.location.reload();
                mostrarMensaje('Membresía registrada correctamente.');
                limpiarCampos();
            })
            .catch(error => {
                mostrarMensaje('Error al registrar la membresía: ' + error);
            });
    });

    const seleccionarFila = (fila) => {
        if (selectedRow) {
            selectedRow.classList.remove('selected');
        }
        selectedRow = fila;
        selectedRow.classList.add('selected');

        // Rellenar campos de texto con los datos de la fila seleccionada
        const celdas = selectedRow.querySelectorAll('td');

        document.getElementById('id').value = celdas[0].textContent;
        clienteSelect.value = celdas[1].textContent;
        document.getElementById('tipo').value = celdas[2].textContent;
        document.getElementById('fechaInicio').value = celdas[3].textContent;
        document.getElementById('fechaFin').value = celdas[4].textContent;
        estadoSelect.value = celdas[5].textContent;
        document.getElementById('monto').value = celdas[6].textContent;

        actualizarButton.disabled = false;
        eliminarButton.disabled = false;
        registrarButton.disabled = true;
    };

    actualizarButton.addEventListener('click', () => {
        if (selectedRow) {
            const membresiaData = {
                id: document.getElementById('id').value,
                tipo: document.getElementById('tipo').value,
                fechaInicio: document.getElementById('fechaInicio').value,
                fechaFin: document.getElementById('fechaFin').value,
                estado: estadoSelect.value,
                monto: document.getElementById('monto').value,
                cliente: { id: clienteSelect.value }
            };


            fetch(`/api/membresias/${membresiaData.id}?ced=${encodeURIComponent(user)}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(membresiaData)
            })
                .then(response => response.json())
                .then(data => {
                    const celdas = selectedRow.querySelectorAll('td');
                    celdas[1].textContent = data.cliente.id;
                    celdas[2].textContent = data.tipo;
                    celdas[3].textContent = data.fechaInicio;
                    celdas[4].textContent = data.fechaFin;
                    celdas[5].textContent = data.estado;
                    celdas[6].textContent = data.monto;

                    mostrarMensaje('Membresía actualizada correctamente.');
                    limpiarCampos();
                })
                .catch(error => {
                    mostrarMensaje('Error al actualizar la membresía: ' + error);
                });
        } else {
            mostrarMensaje('No se pudo actualizar.');
        }
    });

    eliminarButton.addEventListener('click', () => {
        if (selectedRow) {
            const id = document.getElementById('id').value;

            if (confirm('¿Está seguro de que desea eliminar esta membresía?')) {
                fetch(`/api/membresias/${id}?ced=${encodeURIComponent(user)}`, {
                    method: 'DELETE'
                })
                    .then(() => {
                        membresiaTable.removeChild(selectedRow);
                        mostrarMensaje('Membresía eliminada correctamente.');
                        limpiarCampos();
                    })
                    .catch(error => {
                        mostrarMensaje('Error al eliminar la membresía: ' + error);
                    });
            }
        } else {
            mostrarMensaje('No se pudo eliminar.');
        }
    });

    limpiarButton.addEventListener('click', limpiarCampos);
});
