
async function cargarMaquinas() {

    try {
        const response = await fetch('http://localhost:8080/api/maquinas');
        if (!response.ok) {
            throw new Error(`Error al obtener los datos: ${response.statusText}`);
        }
        const maquinas = await response.json();
        console.log('Datos recibidos:', maquinas);
        const tbody = document.querySelector('table tbody');
        tbody.innerHTML = '';
        maquinas.forEach(maquina => {
            console.log('Maquina:', maquina);
            const fila = document.createElement('tr');
            fila.innerHTML = `
                <td>${maquina.id || 'N/A'}</td>
                <td>${maquina.descripcion || 'N/A'}</td>
                <td>${maquina.estado || 'N/A'}</td>
            `;
            fila.addEventListener('click', () => seleccionarFila(fila));
            tbody.appendChild(fila);
        });
    } catch (error) {
        console.error('Error cargando las máquinas:', error);
    }
}

let selectedRow = null;
const form = document.querySelector('form');
const inputs = form.querySelectorAll('input');
const registrarButton = document.getElementById('guardar');
const limpiarButton = document.getElementById('limpiar');
const actualizarButton = document.getElementById('actualizar');
const eliminarButton = document.getElementById('eliminar');
const user = sessionStorage.getItem('user');

actualizarButton.disabled = true;
eliminarButton.disabled = true;


const limpiarCampos = () => {
    inputs.forEach(input => {
        input.value = '';
        input.disabled = false; // Habilita el campo de la ID para permitir nuevas entradas
    });
    actualizarButton.disabled = true;
    eliminarButton.disabled = true;
    registrarButton.disabled = false;
};


const mostrarMensaje = (mensaje) => {
    alert(mensaje);
};


const seleccionarFila = (fila) => {
    if (selectedRow) {
        selectedRow.classList.remove('selected');
    }
    selectedRow = fila;
    selectedRow.classList.add('selected');

    const celdas = selectedRow.querySelectorAll('td');
    document.getElementById('id').value = celdas[0].textContent;
    document.getElementById('descripcion').value = celdas[1].textContent;
    document.getElementById('estado').value = celdas[2].textContent;

    actualizarButton.disabled = false;
    eliminarButton.disabled = false;
    registrarButton.disabled = true;
};


form.addEventListener('submit', (event) => {
    event.preventDefault();

    const maquinaData = Array.from(inputs).reduce((data, input) => {
        data[input.id] = input.value;
        return data;
    }, {});

    if (!maquinaData.id || !maquinaData.descripcion || !maquinaData.estado) {
        mostrarMensaje('No se pudo agregar. Por favor, complete todos los campos requeridos.');
        return;
    }

    fetch(`/api/maquinas?id=${encodeURIComponent(user)}`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(maquinaData)
    })
        .then(response => {
            if (response.status === 409) {
                throw new Error('La máquina ya existe.');
            }
            if (!response.ok) {
                throw new Error('No se pudo registrar la máquina.');
            }
            return response.json();
        })
        .then(data => {
            const nuevaFila = document.createElement('tr');
            nuevaFila.innerHTML = `
                <td>${data.id}</td>
                <td>${data.descripcion}</td>
                <td>${data.estado}</td>
            `;
            nuevaFila.addEventListener('click', () => seleccionarFila(nuevaFila));
            document.querySelector('table tbody').appendChild(nuevaFila);
            mostrarMensaje('Máquina registrada correctamente.');
            limpiarCampos();
        })
        .catch(error => {
            mostrarMensaje('Hubo un error al registrar la máquina: ' + error.message);
        });
});


actualizarButton.addEventListener('click', async() => {
    if (selectedRow) {
        const celdas = selectedRow.querySelectorAll('td');
        const id = celdas[0].textContent;

        const updatedMaquina = {
            id: id,
            descripcion: document.getElementById('descripcion').value,
            estado: document.getElementById('estado').value
        };

        if (!updatedMaquina.descripcion || !updatedMaquina.estado) {
            mostrarMensaje('No se pudo actualizar. Por favor, complete todos los campos requeridos.');
            return;
        }

        try {
            const response = await fetch(`/api/maquinas/${id}?ced=${encodeURIComponent(user)}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(updatedMaquina)
            });
            if (response.ok) {
                celdas[1].textContent = updatedMaquina.descripcion;
                celdas[2].textContent = updatedMaquina.estado;
                mostrarMensaje('Máquina actualizada correctamente.');
                limpiarCampos();
            } else {
                mostrarMensaje('Error: No se puede actualizar porque estas intentando actualizar una llave primaria.');
            }
        } catch (error) {
            mostrarMensaje('Error en la solicitud al actualizar la maquina.');
        }
    } else {
        mostrarMensaje('No se pudo actualizar. Seleccione una máquina.');
    }
});


eliminarButton.addEventListener('click', () => {
    if (selectedRow) {
        const celdas = selectedRow.querySelectorAll('td');
        const id = celdas[0].textContent;

        if (confirm('¿Está seguro de que desea eliminar esta maquina?')){
        fetch(`/api/maquinas/${id}?ced=${encodeURIComponent(user)}`, {
            method: 'DELETE'
        })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Error: No se puede eliminar porque esta ligado a un registro de otra tabla.');
                }
                selectedRow.remove();
                mostrarMensaje('Máquina eliminada correctamente.');
                limpiarCampos();
            })
            .catch(error => {
                mostrarMensaje('Hubo un error al eliminar la máquina: ' + error.message);
            });
        }
    } else {
        mostrarMensaje('Seleccione una máquina para eliminar.');
    }
});


limpiarButton.addEventListener('click', () => {
    limpiarCampos();
});

window.onload = cargarMaquinas;
