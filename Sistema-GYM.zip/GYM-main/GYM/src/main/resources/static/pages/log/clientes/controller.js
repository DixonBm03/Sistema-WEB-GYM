document.addEventListener('DOMContentLoaded', () => {
    const clienteTable = document.querySelector('.cliente-table-container tbody');
    const form = document.querySelector('form');
    const inputs = form.querySelectorAll('input');
    const registrarButton = document.getElementById('guardar');
    const limpiarButton = document.getElementById('limpiar');
    const actualizarButton = document.getElementById('actualizar');
    const eliminarButton = document.getElementById('eliminar');
    const user = sessionStorage.getItem('user');

    let selectedRow = null;

    actualizarButton.disabled = true;
    eliminarButton.disabled = true;

    const cargarClientes = async () => {
        try {
            const response = await fetch('/api/clientes');
            const clientes = await response.json();
            clientes.forEach(cliente => {
                agregarFilaATabla(cliente);
            });
        } catch (error) {
            console.error('Error al cargar clientes:', error);
        }
    };

    const agregarFilaATabla = (cliente) => {
        const nuevaFila = document.createElement('tr');
        nuevaFila.innerHTML = `
        <td>${cliente.id}</td>
        <td>${cliente.nombre}</td>
        <td>${cliente.apellido1}</td>
        <td>${cliente.apellido2}</td>
        <td>${cliente.direccion}</td>
        <td>${cliente.email}</td>
        <td>${cliente.celular}</td>
        <td>${cliente.telHabitacion}</td>
        <td>${cliente.fechaInscripcion}</td>
    `;
        nuevaFila.addEventListener('click', () => seleccionarFila(nuevaFila));
        clienteTable.appendChild(nuevaFila);
    };

    const limpiarCampos = () => {
        inputs.forEach(input => {
            input.value = '';
            input.disabled = false;
        });
        actualizarButton.disabled = true;
        eliminarButton.disabled = true;
        registrarButton.disabled = false;
    };

    const mostrarMensaje = (mensaje) => {
        alert(mensaje);
    };

    form.addEventListener('submit', async (event) => {
        event.preventDefault();
        const clienteData = Array.from(inputs).reduce((data, input) => {
            data[input.id] = input.value;
            return data;
        }, {});

        if (!clienteData.nombre || !clienteData.celular || !clienteData.apellido1) {
            mostrarMensaje('Por favor, complete todos los campos requeridos.');
            return;
        }

        try {
            const response = await fetch(`/api/clientes?ced=${encodeURIComponent(user)}`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(clienteData)
            });

            if (response.ok) {

                window.location.reload();
                mostrarMensaje('Cliente registrado correctamente.');
                limpiarCampos();
            } else if (response.status === 409) {
                mostrarMensaje('Cliente ya existe.');
            } else {
                mostrarMensaje('Cliente ya existe.');
            }
        } catch (error) {
            console.error('Error al registrar cliente:', error);
        }
    });

    const seleccionarFila = (fila) => {
        if (selectedRow) {
            selectedRow.classList.remove('selected');
        }
        selectedRow = fila;
        selectedRow.classList.add('selected');

        const celdas = selectedRow.querySelectorAll('td');
        document.getElementById('id').value = celdas[0].textContent;
        document.getElementById('nombre').value = celdas[1].textContent;
        document.getElementById('apellido1').value = celdas[2].textContent;
        document.getElementById('apellido2').value = celdas[3].textContent;
        document.getElementById('direccion').value = celdas[4].textContent;
        document.getElementById('email').value = celdas[5].textContent;
        document.getElementById('celular').value = celdas[6].textContent;
        document.getElementById('telHabitacion').value = celdas[7].textContent;
        document.getElementById('fechaInscripcion').value = celdas[8].textContent;

        actualizarButton.disabled = false;
        eliminarButton.disabled = false;
        registrarButton.disabled = true;
    };

    actualizarButton.addEventListener('click', async () => {
        if (selectedRow) {
            const id = document.getElementById('id').value;
            const clienteData = Array.from(inputs).reduce((data, input) => {
                data[input.id] = input.value;
                return data;
            }, {});

            try {
                const response = await fetch(`/api/clientes/${id}?ced=${encodeURIComponent(user)}`, {
                    method: 'PUT',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(clienteData)
                });
                if (response.ok) {
                    window.location.reload();
                    mostrarMensaje('Cliente actualizado correctamente.');
                    limpiarCampos();
                } else {
                    mostrarMensaje('Error: No se puede actualizar porque estas intentando actualizar una llave primaria.');
                }
            } catch (error) {
                console.error('Error al actualizar cliente:', error);
            }
        }
    });

    eliminarButton.addEventListener('click', async () => {
        if (selectedRow) {
            const id = document.getElementById('id').value;
            if (confirm('¿Está seguro de que desea eliminar este cliente?')) {
                try {
                    const response = await fetch(`/api/clientes/${id}?ced=${encodeURIComponent(user)}`, { method: 'DELETE' });
                    if (response.ok) {
                        window.location.reload();
                        mostrarMensaje('Cliente eliminado correctamente.');
                        limpiarCampos();
                    } else {
                        mostrarMensaje('Error: No se puede eliminar porque esta ligado a un registro de otra tabla.');
                    }
                } catch (error) {
                    console.error('Error al eliminar cliente:', error);
                }
            }
        }
    });

    limpiarButton.addEventListener('click', () => {
        limpiarCampos();
    });
    cargarClientes();
});
