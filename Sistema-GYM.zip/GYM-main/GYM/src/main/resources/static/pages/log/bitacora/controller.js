document.addEventListener("DOMContentLoaded", () => {
    // Selecciona el <tbody> de la tabla
    const tbody = document.querySelector('.container table tbody');

    const cargarInstructores = async () => {
        try {
            const response = await fetch('/api/bitacora');
            const bitacora = await response.json();
            bitacora.forEach(item => {
                agregarFilaATabla(item);
            });
        } catch (error) {
            console.error('Error al cargar bitacora:', error);
        }
    };

    const agregarFilaATabla = (bitacora) => {
        console.log(bitacora);
        const nuevaFila = document.createElement('tr');
        nuevaFila.innerHTML = `
            <td>${bitacora.usuario}</td>
            <td>${bitacora.tabla}</td>
            <td>${bitacora.accion}</td>
            <td>${bitacora.fecha}</td>
        `;
        nuevaFila.addEventListener('click', () => seleccionarFila(nuevaFila));
        tbody.appendChild(nuevaFila); // Agrega la fila al <tbody>
    };

    cargarInstructores();
});
