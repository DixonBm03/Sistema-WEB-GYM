package cr.ac.una.gym.Curso;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/cursos")
public class GymCursoController {

    @Autowired
    private GymCursoService gymCursoService;

    @GetMapping
    public List<GymCurso> getAllCursos() {
        return gymCursoService.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<GymCurso> getCursoById(@PathVariable Long id) {
        Optional<GymCurso> curso = gymCursoService.findById(id);
        return curso.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<String> createCurso(@RequestBody GymCurso gymCurso, @RequestParam Long ced) {
        Optional<GymCurso> existingCurso = gymCursoService.findById(gymCurso.getId());
        if (existingCurso.isPresent()) {
            return ResponseEntity.status(HttpStatus.CONFLICT)
                    .body("El curso con ID " + gymCurso.getId() + " ya existe.");
        }
        GymCurso savedCurso = gymCursoService.save(gymCurso);
        gymCursoService.auditar(ced, "insert");
        return ResponseEntity.status(HttpStatus.CREATED).body("Curso creado correctamente con ID " + savedCurso.getId());
    }

    @PutMapping("/{id}")
    public ResponseEntity<String> updateCurso(@PathVariable Long id, @RequestBody GymCurso gymCurso, @RequestParam Long ced) {
        Optional<GymCurso> existingCurso = gymCursoService.findById(id);

        if (existingCurso.isPresent()) {
            try {
                gymCursoService.actualizarCurso(id, gymCurso.getDescripcion(), gymCurso.getHorarios());
                gymCursoService.auditar(ced, "update");
                return ResponseEntity.ok("Curso actualizado correctamente");
            } catch (Exception e) {
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                        .body("Error al actualizar curso: " + e.getMessage());
            }
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteCurso(@PathVariable Long id,@RequestParam Long ced ) {
        Optional<GymCurso> existingCurso = gymCursoService.findById(id);
        if (existingCurso.isPresent()) {
            try {
                gymCursoService.eliminarCurso(id);
                gymCursoService.auditar(ced, "delete");
                return ResponseEntity.ok("Curso eliminado correctamente");
            } catch (Exception e) {
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                        .body("Error al eliminar curso: " + e.getMessage());
            }
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}
