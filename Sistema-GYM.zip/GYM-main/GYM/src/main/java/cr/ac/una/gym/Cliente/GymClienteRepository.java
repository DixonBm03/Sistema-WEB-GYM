package cr.ac.una.gym.Cliente;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.Date;

@Repository
public interface GymClienteRepository extends JpaRepository<GymCliente, Long> {

    @Procedure(procedureName = "P_actualizar_cliente")
    void actualizarCliente(
            @Param("p_cedula") Long cedula,
            @Param("p_nombre") String nombre,
            @Param("p_apellido1") String apellido1,
            @Param("p_apellido2") String apellido2,
            @Param("p_direccion") String direccion,
            @Param("p_email") String email,
            @Param("p_celular") Long celular,
            @Param("p_tel_hab") Long telHabitacion,
            @Param("p_fecha") LocalDate fechaInscripcion
    );

    @Procedure(procedureName = "P_eliminar_cliente")
    void eliminarCliente(@Param("p_cedula") Long cedula);

    @Procedure(procedureName = "P_verificarMembresia")
    void verificarMembresia(@Param("cedula") Long cedula);

    // Llamada al procedimiento registrarse
    @Procedure(procedureName = "registrarse")
    void registrarse(
            @Param("ced") Long cedula,
            @Param("p_password") String password,
            @Param("p_nombre") String nombre,
            @Param("p_apellido1") String apellido1,
            @Param("p_apellido2") String apellido2,
            @Param("p_direccion") String direccion,
            @Param("p_email") String email,
            @Param("p_celular") Long celular,
            @Param("p_tel_hab") Long telHabitacion,
            @Param("p_fecha") LocalDate fechaInscripcion
    );

    @Procedure(procedureName = "iniciar_sesion")
    void login(
            @Param("ced") Long cedula,
            @Param("pas") String password,
            @Param("res") String res
    );

    @Query("SELECT g.rol FROM GymUsuario g WHERE g.id = :cedula")
    String findRolById(@Param("cedula") Long cedula);

    @Procedure(name = "auditar")
    void auditar(@Param("ced") Long id,
                 @Param("tabla") String tabla,
                 @Param("accion") String accion);



    @Procedure(procedureName = "desin")
    void desin(@Param("ced") Long cedula);

}


