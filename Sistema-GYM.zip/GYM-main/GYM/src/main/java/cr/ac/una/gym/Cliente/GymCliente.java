package cr.ac.una.gym.Cliente;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import org.hibernate.annotations.ColumnDefault;

import java.time.LocalDate;

@Entity
@Table(name = "GYM_CLIENTE", schema = "SYSTEM")
public class GymCliente {
    @Id
    @Column(name = "CED_CLIENTE", nullable = false)
    private Long id;

    @Size(max = 30)
    @NotNull
    @Column(name = "NOMBRE", nullable = false, length = 30)
    private String nombre;

    @Size(max = 30)
    @NotNull
    @Column(name = "APELLIDO_1", nullable = false, length = 30)
    private String apellido1;

    @Size(max = 30)
    @NotNull
    @Column(name = "APELLIDO_2", nullable = false, length = 30)
    private String apellido2;

    @Size(max = 50)
    @ColumnDefault("'N/A'")
    @Column(name = "DIRECCION", length = 50)
    private String direccion;

    @Size(max = 30)
    @ColumnDefault("'*@*.com'")
    @Column(name = "E_MAIL", length = 30)
    private String eMail;

    @NotNull
    @Column(name = "CELULAR", nullable = false)
    private Long celular;

    @NotNull
    @Column(name = "TEL_HABITACION", nullable = false)
    private Long telHabitacion;

    @NotNull
    @Column(name = "FECHA_INSCRIPCION", nullable = false)
    private LocalDate fechaInscripcion;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido1() {
        return apellido1;
    }

    public void setApellido1(String apellido1) {
        this.apellido1 = apellido1;
    }

    public String getApellido2() {
        return apellido2;
    }

    public void setApellido2(String apellido2) {
        this.apellido2 = apellido2;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getEMail() {
        return eMail;
    }

    public void setEMail(String eMail) {
        this.eMail = eMail;
    }

    public Long getCelular() {
        return celular;
    }

    public void setCelular(Long celular) {
        this.celular = celular;
    }

    public Long getTelHabitacion() {
        return telHabitacion;
    }

    public void setTelHabitacion(Long telHabitacion) {
        this.telHabitacion = telHabitacion;
    }

    public LocalDate getFechaInscripcion() {
        return fechaInscripcion;
    }

    public void setFechaInscripcion(LocalDate fechaInscripcion) {
        this.fechaInscripcion = fechaInscripcion;
    }

}