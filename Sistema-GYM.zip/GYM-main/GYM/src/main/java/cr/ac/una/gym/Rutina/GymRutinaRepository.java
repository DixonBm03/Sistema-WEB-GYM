package cr.ac.una.gym.Rutina;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;

@Repository
public interface GymRutinaRepository extends JpaRepository<GymRutina, Integer> {

    @Procedure(name = "P_actualizar_rutinas")
    void actualizarRutina(
            @Param("cod") Long idRutina,
            @Param("p_cliente") Long cliente,
            @Param("p_inst") Long instructor,
            @Param("p_maq") Long maquina,
            @Param("p_fecha") LocalDate fecha,
            @Param("p_horas") Long horas
    );

    @Procedure(name = "P_eliminar_rutina")
    void eliminarRutina(@Param("cod") int idRutina);

    @Procedure(name = "auditar")
    void auditar(@Param("ced") Long id,
                 @Param("tabla") String tabla,
                 @Param("accion") String accion);

    @Procedure(name = "mostrar_rutinas_cliente")
    List<GymRutina> mostrarRutinasCliente(@Param("p_cliente") Long cliente);

    @Query("SELECT r FROM GymRutina r WHERE r.cliente.id = :clienteId")
    List<GymRutina> mostrarRutinasClientes(@Param("clienteId") Long clienteId);

}
