package cr.ac.una.gym.HistorialCurso;

import cr.ac.una.gym.Cliente.GymCliente;
import cr.ac.una.gym.Curso.GymCurso;
import cr.ac.una.gym.Instructores.GymInstructore;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import java.time.LocalDate;

@Entity
@Table(name = "GYM_HISTORIAL_CURSO", schema = "SYSTEM")
@NamedStoredProcedureQueries({
        @NamedStoredProcedureQuery(
                name = "P_actualizar_historial",
                procedureName = "P_actualizar_historial",
                parameters = {
                        @StoredProcedureParameter(mode = ParameterMode.IN, name = "cod", type = Integer.class),
                        @StoredProcedureParameter(mode = ParameterMode.IN, name = "p_cliente", type = Integer.class),
                        @StoredProcedureParameter(mode = ParameterMode.IN, name = "p_inst", type = Integer.class),
                        @StoredProcedureParameter(mode = ParameterMode.IN, name = "p_curso", type = Integer.class),
                        @StoredProcedureParameter(mode = ParameterMode.IN, name = "p_fecha", type = LocalDate.class),
                        @StoredProcedureParameter(mode = ParameterMode.IN, name = "p_horas", type = Integer.class)
                }
        ),
        @NamedStoredProcedureQuery(
                name = "P_eliminar_historial",
                procedureName = "P_eliminar_historial",
                parameters = {
                        @StoredProcedureParameter(mode = ParameterMode.IN, name = "cod", type = Integer.class)
                }
        )
})
public class GymHistorialCurso {
    @Id
    @Column(name = "ID_HISTORIAL", nullable = false)
    private Long id;

    @NotNull
    @ManyToOne(fetch = FetchType.EAGER, optional = false)
    @OnDelete(action = OnDeleteAction.RESTRICT)
    @JoinColumn(name = "CLIENTE", nullable = false)
    private GymCliente cliente;

    @NotNull
    @ManyToOne(fetch = FetchType.EAGER, optional = false)
    @OnDelete(action = OnDeleteAction.RESTRICT)
    @JoinColumn(name = "INSTRUCTOR", nullable = false)
    private GymInstructore instructor;

    @NotNull
    @ManyToOne(fetch = FetchType.EAGER, optional = false)
    @OnDelete(action = OnDeleteAction.RESTRICT)
    @JoinColumn(name = "CURSO", nullable = false)
    private GymCurso curso;

    @NotNull
    @Column(name = "FECHA", nullable = false)
    private LocalDate fecha;

    @NotNull
    @Column(name = "HORAS", nullable = false)
    private Long horas;

    // Getters y setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public GymCliente getCliente() {
        return cliente;
    }

    public void setCliente(GymCliente cliente) {
        this.cliente = cliente;
    }

    public GymInstructore getInstructor() {
        return instructor;
    }

    public void setInstructor(GymInstructore instructor) {
        this.instructor = instructor;
    }

    public GymCurso getCurso() {
        return curso;
    }

    public void setCurso(GymCurso curso) {
        this.curso = curso;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }

    public Long getHoras() {
        return horas;
    }

    public void setHoras(Long horas) {
        this.horas = horas;
    }
}
