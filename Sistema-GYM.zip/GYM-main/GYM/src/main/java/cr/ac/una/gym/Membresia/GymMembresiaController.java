package cr.ac.una.gym.Membresia;

import cr.ac.una.gym.Cliente.GymCliente;
import cr.ac.una.gym.Cliente.GymClienteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/membresias")
public class GymMembresiaController {

    @Autowired
    private GymMembresiaService gymMembresiaService;

    @Autowired
    private GymClienteService gymClienteService;

    @GetMapping
    public ResponseEntity<List<GymMembresia>> getAllMembresias() {
        try {
            List<GymMembresia> membresias = gymMembresiaService.findAll();
            return ResponseEntity.ok(membresias);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @GetMapping("/{id}")
    public ResponseEntity<GymMembresia> getMembresiaById(@PathVariable Long id) {
        Optional<GymMembresia> membresia = gymMembresiaService.findById(id);
        return membresia.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<GymMembresia> crearMembresia(@RequestBody GymMembresia membresia, @RequestParam Long ced ) {
        Optional<GymCliente> cliente = gymClienteService.findById(membresia.getCliente().getId());
        if (cliente.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        }
        membresia.setCliente(cliente.orElse(null));
        GymMembresia nuevaMembresia = gymMembresiaService.save(membresia);
        gymMembresiaService.auditar(ced, "insert");
        return ResponseEntity.status(HttpStatus.CREATED).body(nuevaMembresia);
    }

    @PutMapping("/{id}")
    public ResponseEntity<GymMembresia> updateMembresia(@PathVariable Long id, @RequestBody GymMembresia gymMembresia,@RequestParam Long ced ) {
        Optional<GymMembresia> existingMembresia = gymMembresiaService.findById(id);
        if (existingMembresia.isPresent()) {
            gymMembresia.setId(id);
            gymMembresiaService.auditar(ced, "update");
            return ResponseEntity.ok(gymMembresiaService.save(gymMembresia));
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteMembresia(@PathVariable Long id, @RequestParam Long ced) {
        if (gymMembresiaService.findById(id).isPresent()) {
            gymMembresiaService.deleteById(id);
            gymMembresiaService.auditar(ced, "delete");
            return ResponseEntity.ok().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}
