package cr.ac.una.gym.Maquina;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class GymMaquinaService {

    @Autowired
    private GymMaquinaRepository gymMaquinaRepository;

    public List<GymMaquina> obtenerMaquinas() {
        return gymMaquinaRepository.findAll();
    }

    public Optional<GymMaquina> obtenerMaquinaPorId(Long id) {
        return gymMaquinaRepository.findById(id);
    }

    //Triggers
    public GymMaquina guardarMaquina(GymMaquina gymMaquina) {
        return gymMaquinaRepository.save(gymMaquina);
    }

    //Procedure
    public void actualizarMaquina(Long idMaquina, String descripcion, String estado) {
        try {
            gymMaquinaRepository.actualizarMaquina(idMaquina, descripcion, estado);
        } catch (DataAccessException e) {
            throw new RuntimeException("Error al actualizar la máquina: " + e.getMessage());
        }
    }

    //Procedure
    public void eliminarMaquina(Long idMaquina) {
        try {
            gymMaquinaRepository.eliminarMaquina(idMaquina);
        } catch (DataAccessException e) {
            throw new RuntimeException("Error al eliminar la máquina: " + e.getMessage());
        }
    }

    //Procedures
    public void auditar(Long id, String accion) {
        String tabla= "GYM_Maquinas";
        try {
            gymMaquinaRepository.auditar(id, tabla, accion);
        } catch (DataAccessException e) {
            throw new RuntimeException("Error al auditar: " + e.getMessage());
        }
    }
}

