package cr.ac.una.gym.Instructores;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
public class GymInstructoreService {

    @Autowired
    private GymInstructoreRepository gymInstructoreRepository;

    public List<GymInstructore> obtenerInstructores() {
        return gymInstructoreRepository.findAll();
    }

    public Optional<GymInstructore> obtenerInstructorPorId(Long id) {
        return gymInstructoreRepository.findById(id);
    }

    //Trigger
    public GymInstructore guardarInstructor(GymInstructore gymInstructore) {
        return gymInstructoreRepository.save(gymInstructore);
    }

    //Procedure
    public void actualizarInstructor(Long idInstructor, String nombre, String apellido1, String apellido2, String direccion, String eMail, Long celular, Long telHabitacion, LocalDate fechaContratacion) {
        try {
            gymInstructoreRepository.P_actualizar_instructores(
                    idInstructor.intValue(), nombre, apellido1, apellido2, direccion, eMail, Math.toIntExact(celular), Math.toIntExact(telHabitacion), fechaContratacion
            );
        } catch (DataAccessException e) {
            throw new RuntimeException("Error al actualizar el instructor: " + e.getMessage());
        }
    }

    //Procedure
    public void eliminarInstructor(Long idInstructor) {
        try {
            gymInstructoreRepository.P_eliminar_instructor(idInstructor);
        } catch (DataAccessException e) {
            throw new RuntimeException("Error al eliminar el instructor: " + e.getMessage());
        }
    }

    //Procedure
    public List<Object[]> obtenerInfoInstructor(String nombreInstructor) {
        try {
            return gymInstructoreRepository.obtener_info_instructor(nombreInstructor);
        } catch (DataAccessException e) {
            throw new RuntimeException("Error al obtener información del instructor: " + e.getMessage());
        }
    }

    //Procedures
    public void auditar(Long id, String accion) {
        String tabla= "GYM_Instructores";
        try {
            gymInstructoreRepository.auditar(id, tabla, accion);
        } catch (DataAccessException e) {
            throw new RuntimeException("Error al auditar: " + e.getMessage());
        }
    }
}
