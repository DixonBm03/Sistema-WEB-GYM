package cr.ac.una.gym.Curso;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface GymCursoRepository  extends JpaRepository<GymCurso, Long> {

    @Procedure(procedureName = "P_actualizar_cursos")
    void actualizarCurso(@Param("cod") Long codigo,
                         @Param("p_descripcion") String descripcion,
                         @Param("p_horarios") String horarios);

    @Procedure(procedureName = "P_eliminar_curso")
    void eliminarCurso(@Param("cod") Long codigo);

    @Procedure(name = "auditar")
    void auditar(@Param("ced") Long id,
                 @Param("tabla") String tabla,
                 @Param("accion") String accion);
}
