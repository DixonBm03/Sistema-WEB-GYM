package cr.ac.una.gym.Bitacora;

import cr.ac.una.gym.Instructores.GymInstructore;
import cr.ac.una.gym.Instructores.GymInstructoreService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/bitacora")
public class GymAuditoriaController {
    @Autowired
    private GymAuditoriaService gymAuditService;

    @GetMapping
    public List<GymAuditoria> listarBitacora() {
        List<GymAuditoria> list = gymAuditService.obtenerBitacora();
        return list;
    }
}
