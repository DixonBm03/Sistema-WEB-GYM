package cr.ac.una.gym.Membresia;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface GymMembresiaRepository extends JpaRepository<GymMembresia, Long> {
    @Procedure(name = "auditar")
    void auditar(@Param("ced") Long id,
                 @Param("tabla") String tabla,
                 @Param("accion") String accion);
}
