package cr.ac.una.gym.HistorialCurso;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;

@Repository
public interface GymHistorialCursoRepository extends JpaRepository<GymHistorialCurso, Integer> {

    @Procedure(name = "P_actualizar_historial")
    void actualizarHistorial(
            @Param("cod") Long idHistorial,
            @Param("p_cliente") Long clienteId,
            @Param("p_inst") Long instructorId,
            @Param("p_curso") Long cursoId,
            @Param("p_fecha") LocalDate fecha,
            @Param("p_horas") Integer horas
    );

    @Procedure(name = "P_eliminar_historial")
    void eliminarHistorial(@Param("cod") Long idHistorial);

    @Procedure(name = "auditar")
    void auditar(@Param("ced") Long id,
                 @Param("tabla") String tabla,
                 @Param("accion") String accion);

    @Query("SELECT h FROM GymHistorialCurso h WHERE h.cliente.id = :clienteId")
    List<GymHistorialCurso> mostrarCursosCliente(@Param("clienteId") Long clienteId);
}

