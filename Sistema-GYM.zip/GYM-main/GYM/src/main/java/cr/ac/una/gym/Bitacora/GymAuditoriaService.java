package cr.ac.una.gym.Bitacora;

import cr.ac.una.gym.Instructores.GymInstructore;
import cr.ac.una.gym.Instructores.GymInstructoreRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class GymAuditoriaService {

    @Autowired
    private GymAuditoriaRepository gymAuditRepository;

    public List<GymAuditoria> obtenerBitacora() {
        return gymAuditRepository.findAll();
    }
}
