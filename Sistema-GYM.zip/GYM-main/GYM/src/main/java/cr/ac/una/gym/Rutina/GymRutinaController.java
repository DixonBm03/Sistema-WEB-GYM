package cr.ac.una.gym.Rutina;

import cr.ac.una.gym.Cliente.GymCliente;
import cr.ac.una.gym.Cliente.GymClienteRepository;
import cr.ac.una.gym.Cliente.GymClienteService;
import cr.ac.una.gym.Instructores.GymInstructore;
import cr.ac.una.gym.Instructores.GymInstructoreRepository;
import cr.ac.una.gym.Maquina.GymMaquina;
import cr.ac.una.gym.Maquina.GymMaquinaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

@RestController
@RequestMapping("/api/rutinas")
public class GymRutinaController {

    @Autowired
    private GymRutinaService gymRutinaService;

    @Autowired
    private GymClienteRepository clienteRepository;

    @Autowired
    private GymInstructoreRepository instructorRepository;

    @Autowired
    private GymMaquinaRepository maquinaRepository;
    @Autowired
    private GymClienteService gymClienteService;

    @GetMapping
    public List<GymRutina> getAllRutinas() {
        List<GymRutina> rutinas = gymRutinaService.findAll();
        return rutinas;
    }

    @PostMapping
    public ResponseEntity<?> crearRutina(@RequestBody GymRutina rutina, @RequestParam Long ced ) {
        try {
            GymCliente cliente = clienteRepository.findById(rutina.getCliente().getId())
                    .orElseThrow(() -> new IllegalArgumentException("Cliente no encontrado"));
            GymInstructore instructor = instructorRepository.findById(rutina.getInstructor().getId())
                    .orElseThrow(() -> new IllegalArgumentException("Instructor no encontrado"));
            GymMaquina maquina = maquinaRepository.findById(rutina.getMaquina().getId())
                    .orElseThrow(() -> new IllegalArgumentException("Máquina no encontrada"));

            rutina.setCliente(cliente);
            rutina.setInstructor(instructor);
            rutina.setMaquina(maquina);

            String membresia = gymClienteService.verificarMembresia(rutina.getCliente().getId());
            if (Objects.equals(membresia, "Activo")) {
                gymRutinaService.save(rutina);
                gymRutinaService.auditar(ced, "insert");
                return ResponseEntity.ok("Activo");
            } else {
                return ResponseEntity.status(HttpStatus.FORBIDDEN).body("inactivo");
            }
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error al registrar rutina: " + e.getMessage());
        }
    }

    @PutMapping("/actualizar/{id}")
    public ResponseEntity<?> actualizarRutina(@PathVariable Long id, @RequestBody GymRutina rutina, @RequestParam Long ced) {
        try {
            gymRutinaService.actualizarRutina(id, rutina.getCliente().getId(), rutina.getInstructor().getId(), rutina.getMaquina().getId(), rutina.getFecha(), rutina.getHoras());
            gymRutinaService.auditar(ced, "update");
            return ResponseEntity.ok("Rutina actualizada correctamente.");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error al actualizar la rutina.");
        }
    }

    @DeleteMapping("/eliminar/{idRutina}")
    public ResponseEntity<String> eliminarRutina(@PathVariable int idRutina, @RequestParam Long ced) {
        try {
            gymRutinaService.eliminarRutina(idRutina);
            gymRutinaService.auditar(ced, "delete");
            return ResponseEntity.ok("Rutina eliminada correctamente");
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
        }
    }

    @GetMapping("/cliente/{idCliente}")
    public ResponseEntity<List<GymRutina>> getRutinasByCliente(@PathVariable Long idCliente) {
        try {
            List<GymRutina> rutinas = gymRutinaService.mostrarRutinas(idCliente);
            if (rutinas.isEmpty()) {
                return ResponseEntity.noContent().build(); // No hay rutinas
            }
            return ResponseEntity.ok(rutinas); // Retorna las rutinas
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }

}
