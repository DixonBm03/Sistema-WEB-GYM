package cr.ac.una.gym.Cliente;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/clientes")
public class GymClienteController {

    @Autowired
    private GymClienteService gymClienteService;

    @GetMapping
    public ResponseEntity<List<GymCliente>> getAllClientes() {
        try {
            List<GymCliente> clientes = gymClienteService.findAll();
            return ResponseEntity.ok(clientes);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }

    @GetMapping("/{id}")
    public ResponseEntity<GymCliente> getClienteById(@PathVariable Long id) {
        Optional<GymCliente> cliente = gymClienteService.findById(id);
        return cliente.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<String> createCliente(@RequestBody GymCliente gymCliente, @RequestParam Long ced) {
        Optional<GymCliente> existingCliente = gymClienteService.findById(gymCliente.getId());
        if (existingCliente.isPresent()) {
            return ResponseEntity.status(HttpStatus.CONFLICT)
                    .body("El cliente con ID " + gymCliente.getId() + " ya existe.");
        }
        GymCliente savedCliente = gymClienteService.save(gymCliente);
        gymClienteService.auditar(ced, "insert");
        return ResponseEntity.status(HttpStatus.CREATED).body("Cliente creado correctamente con ID " + savedCliente.getId());
    }

    @PutMapping("/{id}")
    public ResponseEntity<String> updateCliente(@PathVariable Long id, @RequestBody GymCliente gymCliente, @RequestParam Long ced) {
        Optional<GymCliente> existingCliente = gymClienteService.findById(id);
        if (existingCliente.isPresent()) {
            try {
                gymCliente.setId(id);
                gymClienteService.actualizarCliente(gymCliente);
                gymClienteService.auditar(ced, "update");
                return ResponseEntity.ok("Cliente actualizado correctamente");
            } catch (Exception e) {
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                        .body("Error al actualizar cliente: " + e.getMessage());
            }
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteCliente(@PathVariable Long id, @RequestParam Long ced) {
        Optional<GymCliente> existingCliente = gymClienteService.findById(id);
        if (existingCliente.isPresent()) {
            try {
                gymClienteService.eliminarCliente(id);
                gymClienteService.auditar(ced, "delete");
                return ResponseEntity.ok("Cliente eliminado correctamente");
            } catch (Exception e) {
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                        .body("Error al eliminar cliente: " + e.getMessage());
            }
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @PostMapping("/registrarse")
    public ResponseEntity<String> registrarCliente(@RequestBody GymCliente gymCliente, @RequestParam String password) {
        try {
            // Verificar si el cliente ya existe
            Optional<GymCliente> existingCliente = gymClienteService.findById(gymCliente.getId());
            if (existingCliente.isPresent()) {
                return ResponseEntity.status(HttpStatus.CONFLICT)
                        .body("El cliente con ID " + gymCliente.getId() + " ya está registrado.");
            }

            // Llamar al servicio para registrar el cliente
            gymClienteService.registrarCliente(
                    gymCliente.getId(), password, gymCliente.getNombre(), gymCliente.getApellido1(),
                    gymCliente.getApellido2(), gymCliente.getDireccion(), gymCliente.getEMail(),
                    gymCliente.getCelular(), gymCliente.getTelHabitacion(), gymCliente.getFechaInscripcion()
            );
            return ResponseEntity.status(HttpStatus.CREATED).body("Cliente registrado correctamente.");
        } catch (Exception e) {
            // Log de la excepción
            e.printStackTrace(); // Esto te ayudará a ver el error en los logs
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Ocurrió un error al registrar el cliente: " + e.getMessage());
        }
    }

    @PostMapping("/login")
    public ResponseEntity<String> login(@RequestParam Long cedula, @RequestParam String password) {
        String rol = gymClienteService.login(cedula, password);

        if (rol != null && !rol.isEmpty()) {
            return ResponseEntity.status(HttpStatus.OK).body(rol);
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Credenciales incorrectas");
        }
    }

    @DeleteMapping("/desin")
    public ResponseEntity<String> desin(@RequestParam Long ced) {
        try {
            gymClienteService.desin(ced);
            return ResponseEntity.ok("Cliente eliminado correctamente");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error al desinscribir cliente: " + e.getMessage());
        }
    }
}


