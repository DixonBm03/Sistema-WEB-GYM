package cr.ac.una.gym.Bitacora;

import cr.ac.una.gym.Instructores.GymInstructore;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface GymAuditoriaRepository extends JpaRepository<GymAuditoria, Long> {
}
