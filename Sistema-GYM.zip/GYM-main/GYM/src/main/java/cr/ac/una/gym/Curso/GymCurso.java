package cr.ac.una.gym.Curso;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

@Entity
@Table(name = "GYM_CURSOS", schema = "SYSTEM")
public class GymCurso {
    @Id
    @Column(name = "ID_CURSO", nullable = false)
    private Long id;

    @Size(max = 50)
    @NotNull
    @Column(name = "DESCRIPCION", nullable = false, length = 50)
    private String descripcion;

    @Size(max = 50)
    @NotNull
    @Column(name = "HORARIOS", nullable = false, length = 50)
    private String horarios;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getHorarios() {
        return horarios;
    }

    public void setHorarios(String horarios) {
        this.horarios = horarios;
    }

}