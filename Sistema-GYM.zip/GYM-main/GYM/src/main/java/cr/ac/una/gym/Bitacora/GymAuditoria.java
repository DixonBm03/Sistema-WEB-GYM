package cr.ac.una.gym.Bitacora;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import org.hibernate.annotations.ColumnDefault;

@Entity
@Table(name = "GYM_AUDITORIA", schema = "SYSTEM")
public class GymAuditoria {
    @Id
    @ColumnDefault("SYSTEM.SEC.NEXTVAL")
    @Column(name = "ID_AUDIT", nullable = false)
    private Long id;

    @Size(max = 30)
    @NotNull
    @Column(name = "USUARIO", nullable = false, length = 30)
    private String usuario;

    @Size(max = 30)
    @NotNull
    @Column(name = "TABLA", nullable = false, length = 30)
    private String tabla;

    @Size(max = 30)
    @NotNull
    @Column(name = "ACCION", nullable = false, length = 30)
    private String accion;

    @Size(max = 50)
    @NotNull
    @Column(name = "FECHA", nullable = false, length = 50)
    private String fecha;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getTabla() {
        return tabla;
    }

    public void setTabla(String tabla) {
        this.tabla = tabla;
    }

    public String getAccion() {
        return accion;
    }

    public void setAccion(String accion) {
        this.accion = accion;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

}