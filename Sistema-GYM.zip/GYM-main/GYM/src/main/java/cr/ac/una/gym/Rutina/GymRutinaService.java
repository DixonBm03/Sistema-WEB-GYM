package cr.ac.una.gym.Rutina;

import cr.ac.una.gym.Cliente.GymClienteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@Service
public class GymRutinaService {

    @Autowired
    private GymRutinaRepository gymRutinaRepository;
    @Autowired
    private GymClienteService gymClienteService;

    public List<GymRutina> findAll() {
        List<GymRutina> rutinas = gymRutinaRepository.findAll();
        return rutinas;
    }

    //Triggers
    public GymRutina save(GymRutina gymRutina) {
        return gymRutinaRepository.save(gymRutina);
    }

    //Procedure
    public void actualizarRutina(Long idRutina, Long cliente, Long instructor, Long maquina, LocalDate fecha, Long horas) {
        try {
            gymRutinaRepository.actualizarRutina(idRutina, cliente, instructor, maquina, fecha, horas);
        } catch (DataAccessException e) {
            throw new RuntimeException("Error al actualizar la rutina: " + e.getMessage());
        }
    }

    //Procedure
    public void eliminarRutina(int idRutina) {
        try {
            gymRutinaRepository.eliminarRutina(idRutina);
        } catch (DataAccessException e) {
            throw new RuntimeException("Error al eliminar la rutina: " + e.getMessage());
        }
    }

    //Procedure
    public void auditar(Long id, String accion) {
        String tabla= "GYM_rutinas";
        try {
            gymRutinaRepository.auditar(id, tabla, accion);
        } catch (DataAccessException e) {
            throw new RuntimeException("Error al auditar: " + e.getMessage());
        }
    }

    //Procedure
    public List<GymRutina> mostrarRutinas(Long clienteId) {
        return gymRutinaRepository.mostrarRutinasClientes(clienteId); // Llamada al procedimiento
    }
}
