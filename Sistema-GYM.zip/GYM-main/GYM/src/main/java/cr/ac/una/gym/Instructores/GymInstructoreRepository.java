package cr.ac.una.gym.Instructores;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface GymInstructoreRepository extends JpaRepository<GymInstructore, Long> {

    @Procedure(name = "P_actualizar_instructores")
    void P_actualizar_instructores(
            @Param("cod") int codInstructor,
            @Param("p_nombre") String nombre,
            @Param("p_apellido1") String apellido1,
            @Param("p_apellido2") String apellido2,
            @Param("p_direccion") String direccion,
            @Param("p_email") String eMail,
            @Param("p_celular") Integer celular,
            @Param("p_tel_hab") Integer telHabitacion,
            @Param("p_fecha") LocalDate fechaContratacion
    );

    @Procedure(name = "P_eliminar_instructor")
    void P_eliminar_instructor(@Param("cod") Long id);


    @Query(value = "CALL obtener_info_instructor(:nombre_instructor)", nativeQuery = true)
    List<Object[]> obtener_info_instructor(@Param("nombre_instructor") String nombreInstructor);

    @Procedure(name = "auditar")
    void auditar(@Param("ced") Long id,
                 @Param("tabla") String tabla,
                 @Param("accion") String accion);
}
