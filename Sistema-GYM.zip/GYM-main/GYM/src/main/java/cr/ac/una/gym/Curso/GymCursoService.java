package cr.ac.una.gym.Curso;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class GymCursoService {

    @Autowired
    private GymCursoRepository gymCursoRepository;

    public List<GymCurso> findAll() {
        return gymCursoRepository.findAll();
    }

    public Optional<GymCurso> findById(Long id) {
        return gymCursoRepository.findById(id);
    }

    //Usa trigger
    public GymCurso save(GymCurso gymCurso) {
        return gymCursoRepository.save(gymCurso);
    }

    //Procedure
    public void actualizarCurso(Long codigo, String descripcion, String horarios) {
        gymCursoRepository.actualizarCurso(codigo, descripcion, horarios);
    }

    //Procedure
    public void eliminarCurso(Long codigo) {
        gymCursoRepository.eliminarCurso(codigo);
    }

    //Procedures
    public void auditar(Long id, String accion) {
        String tabla= "GYM_cursos";
        try {
            gymCursoRepository.auditar(id, tabla, accion);
        } catch (DataAccessException e) {
            throw new RuntimeException("Error al auditar: " + e.getMessage());
        }
    }
}
