package cr.ac.una.gym.Cliente;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

@Entity
@Table(name = "GYM_USUARIOS", schema = "SYSTEM")
public class GymUsuario {
    @Id
    @Column(name = "ID_USUARIO", nullable = false)
    private Long id;

    @Size(max = 30)
    @NotNull
    @Column(name = "CLAVE", nullable = false, length = 30)
    private String clave;

    @Size(max = 30)
    @NotNull
    @Column(name = "ROL", nullable = false, length = 30)
    private String rol;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getClave() {
        return clave;
    }

    public void setClave(String clave) {
        this.clave = clave;
    }

    public String getRol() {
        return rol;
    }

    public void setRol(String rol) {
        this.rol = rol;
    }

}