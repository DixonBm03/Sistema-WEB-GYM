package cr.ac.una.gym.Membresia;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class GymMembresiaService {

    @Autowired
    private GymMembresiaRepository gymMembresiaRepository;

    public List<GymMembresia> findAll() {
        return gymMembresiaRepository.findAll();
    }

    public Optional<GymMembresia> findById(Long id) {
        return gymMembresiaRepository.findById(id);
    }

    public GymMembresia save(GymMembresia gymMembresia) {
        return gymMembresiaRepository.save(gymMembresia);
    }

    public void deleteById(Long id) {
        gymMembresiaRepository.deleteById(id);
    }

    //Procedures
    public void auditar(Long id, String accion) {
        String tabla= "GYM_membresia";
        try {
            gymMembresiaRepository.auditar(id, tabla, accion);
        } catch (DataAccessException e) {
            throw new RuntimeException("Error al auditar: " + e.getMessage());
        }
    }
}
