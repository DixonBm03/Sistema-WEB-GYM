package cr.ac.una.gym.Instructores;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/instructores")
public class GymInstructoreController {

    @Autowired
    private GymInstructoreService gymInstructoreService;

    @GetMapping
    public List<GymInstructore> listarInstructores() {
        List<GymInstructore> list = gymInstructoreService.obtenerInstructores();
        return list;
    }

    @GetMapping("/{id}")
    public ResponseEntity<GymInstructore> obtenerInstructor(@PathVariable Long id) {
        Optional<GymInstructore> instructor = gymInstructoreService.obtenerInstructorPorId(id);
        return instructor.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<Object> crearInstructor(@RequestBody GymInstructore gymInstructore, @RequestParam Long ced ) {
        try {
            Optional<GymInstructore> instructorExistente = gymInstructoreService.obtenerInstructorPorId(gymInstructore.getId());
            if (instructorExistente.isPresent()) {
                return new ResponseEntity<>(HttpStatus.CONFLICT);
            }

            GymInstructore nuevoInstructor = gymInstructoreService.guardarInstructor(gymInstructore);
            gymInstructoreService.auditar(ced, "insert");
            if (nuevoInstructor != null) {
                return new ResponseEntity<>(nuevoInstructor, HttpStatus.CREATED);
            }
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        } catch (Exception e) {
            String errorMessage = e.getMessage();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorMessage);
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<GymInstructore> actualizarInstructor(@PathVariable Long id, @RequestBody GymInstructore gymInstructore, @RequestParam Long ced) {
        Optional<GymInstructore> instructorData = gymInstructoreService.obtenerInstructorPorId(id);
        if (instructorData.isPresent()) {
            String nombre = gymInstructore.getNombre();
            String apellido1 = gymInstructore.getApellido1();
            String apellido2 = gymInstructore.getApellido2();
            String direccion = gymInstructore.getDireccion();
            String eMail = gymInstructore.getEMail();
            Long celular = gymInstructore.getCelular();
            Long telHabitacion = gymInstructore.getTelHabitacion();
            LocalDate fechaContratacion = gymInstructore.getFechaContratacion();

            gymInstructoreService.actualizarInstructor(id, nombre, apellido1, apellido2, direccion, eMail, celular, telHabitacion, fechaContratacion);
            gymInstructoreService.auditar(ced, "update");
            GymInstructore instructorActualizado = instructorData.get();
            instructorActualizado.setNombre(nombre);
            instructorActualizado.setApellido1(apellido1);
            instructorActualizado.setApellido2(apellido2);
            instructorActualizado.setDireccion(direccion);
            instructorActualizado.setEMail(eMail);
            instructorActualizado.setCelular(celular);
            instructorActualizado.setTelHabitacion(telHabitacion);
            instructorActualizado.setFechaContratacion(fechaContratacion);

            return new ResponseEntity<>(instructorActualizado, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<HttpStatus> deleteMaquina(@PathVariable Long id, @RequestParam Long ced) {
        Optional<GymInstructore> instructorExistente = gymInstructoreService.obtenerInstructorPorId(id);
        if (instructorExistente.isPresent()) {
            gymInstructoreService.eliminarInstructor(id);
            gymInstructoreService.auditar(ced, "delete");
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
}
