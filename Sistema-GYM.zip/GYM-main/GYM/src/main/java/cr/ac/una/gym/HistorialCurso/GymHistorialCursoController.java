package cr.ac.una.gym.HistorialCurso;

import cr.ac.una.gym.Cliente.GymClienteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

@RestController
@RequestMapping("/api/historialCursos")
public class GymHistorialCursoController {

    @Autowired
    private GymHistorialCursoService gymHistorialCursoService;

    @Autowired
    private GymClienteService gymClienteService;

    @GetMapping
    public List<GymHistorialCurso> getAllHistorialCursos() {
        List<GymHistorialCurso> gymHistorialCursos = gymHistorialCursoService.findAll();
        return gymHistorialCursos;
    }

    // Crear un nuevo historial
    @PostMapping
    public ResponseEntity<String> createHistorialCurso(@RequestBody GymHistorialCurso gymHistorialCurso, @RequestParam Long ced) {
        String membresia = gymClienteService.verificarMembresia(gymHistorialCurso.getCliente().getId());

        if (Objects.equals(membresia, "Activo")) {
            gymHistorialCursoService.auditar(ced, "insert");
            gymHistorialCursoService.save(gymHistorialCurso);
            return ResponseEntity.ok("activo");
        } else {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("inactivo");
        }
    }

    // Eliminar un historial
    @DeleteMapping("/{id}") // Ajustamos la ruta para que sea más consistente
    public ResponseEntity<?> eliminarHistorial(@PathVariable Long id, @RequestParam Long ced) {
        try {
            gymHistorialCursoService.eliminarHistorial(id);
            gymHistorialCursoService.auditar(ced, "delete");
            return ResponseEntity.ok("Historial eliminado correctamente.");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> actualizarHistorial(@PathVariable Long id, @RequestBody GymHistorialCurso historial, @RequestParam Long ced) {
        try {
            gymHistorialCursoService.actualizarHistorial(
                    id,
                    historial.getCliente().getId(),
                    historial.getInstructor().getId(),
                    historial.getCurso().getId(),
                    historial.getFecha(),
                    Math.toIntExact(historial.getHoras())
            );
            gymHistorialCursoService.auditar(ced, "update");
            return ResponseEntity.ok("Historial actualizado correctamente.");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
        }
    }

    @GetMapping("/cliente/{clienteId}")
    public ResponseEntity<List<GymHistorialCurso>> getHistorialByCliente(@PathVariable Long clienteId) {
        try {
            // Llamamos al servicio que obtiene el historial de cursos del cliente
            List<GymHistorialCurso> historial = gymHistorialCursoService.mostrarCursos(clienteId);
            if (historial.isEmpty()) {
                return ResponseEntity.noContent().build();
            }
            return ResponseEntity.ok(historial);
        } catch (Exception e) {
            return ResponseEntity.status(500).body(null);
        }
    }


}
