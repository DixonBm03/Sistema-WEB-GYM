package cr.ac.una.gym.HistorialCurso;

import cr.ac.una.gym.Rutina.GymRutina;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@Service
public class GymHistorialCursoService {

    @Autowired
    private GymHistorialCursoRepository gymHistorialCursoRepository;

    public List<GymHistorialCurso> findAll() {
        return gymHistorialCursoRepository.findAll();
    }

    //Triggers
    public GymHistorialCurso save(GymHistorialCurso gymHistorialCurso) {
        return gymHistorialCursoRepository.save(gymHistorialCurso);
    }

    //Procedure
    public void actualizarHistorial(Long idHistorial, Long cliente, Long instructor, Long curso, LocalDate fecha, Integer horas) {
        try {
            gymHistorialCursoRepository.actualizarHistorial(idHistorial, cliente, instructor, curso, fecha, horas);
        } catch (DataAccessException e) {
            throw new RuntimeException("Error al actualizar el historial del curso: " + e.getMessage());
        }
    }

    //Procedure
    public void eliminarHistorial(Long idHistorial) {
        try {
            gymHistorialCursoRepository.eliminarHistorial(idHistorial);
        } catch (DataAccessException e) {
            throw new RuntimeException("Error al eliminar el historial del curso: " + e.getMessage());
        }
    }

    //Procedures
    public void auditar(Long id, String accion) {
        String tabla= "GYM_historial_curso";
        try {
            gymHistorialCursoRepository.auditar(id, tabla, accion);
        } catch (DataAccessException e) {
            throw new RuntimeException("Error al auditar: " + e.getMessage());
        }
    }

    //Procedure
    public List<GymHistorialCurso> mostrarCursos(Long clienteId) {
        return gymHistorialCursoRepository.mostrarCursosCliente(clienteId);
    }
}
