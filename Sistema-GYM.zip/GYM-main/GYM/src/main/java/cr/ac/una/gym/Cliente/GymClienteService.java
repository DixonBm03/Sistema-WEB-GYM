package cr.ac.una.gym.Cliente;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
public class GymClienteService {

    @Autowired
    private GymClienteRepository gymClienteRepository;

    public List<GymCliente> findAll() {
        return gymClienteRepository.findAll();
    }

    public Optional<GymCliente> findById(Long id) {
        return gymClienteRepository.findById(id);
    }

    //Triggers
    public GymCliente save(GymCliente gymCliente) {
        return gymClienteRepository.save(gymCliente);
    }

    //Procedures
    public void actualizarCliente(GymCliente cliente) {
        gymClienteRepository.actualizarCliente(
                cliente.getId(),
                cliente.getNombre(),
                cliente.getApellido1(),
                cliente.getApellido2(),
                cliente.getDireccion(),
                cliente.getEMail(),
                cliente.getCelular(),
                cliente.getTelHabitacion(),
                cliente.getFechaInscripcion()
        );
    }

    //Procedures
    public void eliminarCliente(Long cedula) {
        gymClienteRepository.eliminarCliente(cedula);
    }

    //Procedures
    public void registrarCliente(Long cedula, String password, String nombre, String apellido1, String apellido2,
                                 String direccion, String email, Long celular, Long telHab, LocalDate fecha) {
        gymClienteRepository.registrarse(cedula, password, nombre, apellido1, apellido2, direccion, email, celular, telHab, fecha);
    }

    //Procedures
    public String login(Long cedula, String password) {
        String res = "";
        gymClienteRepository.login(cedula, password, res);
        return gymClienteRepository.findRolById(cedula);
    }

    //Procedures
    public void auditar(Long id, String accion) {
        String tabla= "GYM_Cliente";
        try {
            gymClienteRepository.auditar(id, tabla, accion);
        } catch (DataAccessException e) {
            throw new RuntimeException("Error al auditar: " + e.getMessage());
        }
    }

    public void desin(Long id) {
        try {
            gymClienteRepository.desin(id);
        } catch (DataAccessException e) {
            throw new RuntimeException("Error al desinscribir: " + e.getMessage());
        }
    }

    //Procedures
    public String verificarMembresia(Long cedula) {
        try {
            gymClienteRepository.verificarMembresia(cedula);
            return "Activo";
        } catch (DataAccessException e) {
            if (e.getMessage().contains("La membresia del cliente esta inactiva")) {
                return "Inactivo";
            } else if (e.getMessage().contains("El cliente no tiene membresia asociada")) {
                return "Inactivo";
            }
            throw new RuntimeException("Error al verificar membresía: " + e.getMessage());
        }
    }
}


