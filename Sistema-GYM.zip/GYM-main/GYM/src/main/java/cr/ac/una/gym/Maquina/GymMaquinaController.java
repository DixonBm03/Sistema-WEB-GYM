package cr.ac.una.gym.Maquina;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/maquinas")
public class GymMaquinaController {

    @Autowired
    private GymMaquinaService gymMaquinaService;

    @GetMapping
    public List<GymMaquina> listarMaquinas() {
        return gymMaquinaService.obtenerMaquinas();
    }

    @GetMapping("/{id}")
    public ResponseEntity<GymMaquina> obtenerMaquina(@PathVariable Long id) {
        Optional<GymMaquina> maquina = gymMaquinaService.obtenerMaquinaPorId(id);
        return maquina.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<Object> crearMaquina(@RequestBody GymMaquina gymMaquina, @RequestParam Long id) {
        try {
            Optional<GymMaquina> maquinaExistente = gymMaquinaService.obtenerMaquinaPorId(gymMaquina.getId());
            if (maquinaExistente.isPresent()) {
                return new ResponseEntity<>(HttpStatus.CONFLICT);
            }

            GymMaquina nuevaMaquina = gymMaquinaService.guardarMaquina(gymMaquina);
            gymMaquinaService.auditar(id, "insert");
            if (nuevaMaquina != null) {
                return new ResponseEntity<>(nuevaMaquina, HttpStatus.CREATED);
            }

            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        } catch (Exception e) {
            String errorMessage = e.getMessage();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorMessage);
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<GymMaquina> updateMaquina(@PathVariable Long id, @RequestBody GymMaquina gymMaquina, @RequestParam Long ced) {
        Optional<GymMaquina> maquinaData = gymMaquinaService.obtenerMaquinaPorId(id);

        if (maquinaData.isPresent()) {
            if (maquinaData.get().getId().equals(gymMaquina.getId())) {
                return new ResponseEntity<>(HttpStatus.CONFLICT);
            }

            String descripcion = gymMaquina.getDescripcion();
            String estado = gymMaquina.getEstado();

            gymMaquinaService.actualizarMaquina(id, descripcion, estado);
            gymMaquinaService.auditar(ced, "update");

            GymMaquina updatedMaquina = maquinaData.get();
            updatedMaquina.setDescripcion(descripcion);
            updatedMaquina.setEstado(estado);

            return new ResponseEntity<>(updatedMaquina, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }


    @DeleteMapping("/{id}")
    public ResponseEntity<HttpStatus> deleteMaquina(@PathVariable Long id, @RequestParam Long ced ) {
        Optional<GymMaquina> maquinaExistente = gymMaquinaService.obtenerMaquinaPorId(id);
        if (maquinaExistente.isPresent()) {
            gymMaquinaService.eliminarMaquina(id);
            gymMaquinaService.auditar(ced, "delete");
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

}

