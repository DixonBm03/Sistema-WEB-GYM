package cr.ac.una.gym.Maquina;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface GymMaquinaRepository extends JpaRepository<GymMaquina, Long> {

    @Procedure(name = "P_actualizar_maquinas")
    void actualizarMaquina(@Param("cod") Long cod,
                           @Param("p_descripcion") String descripcion,
                           @Param("p_estado") String estado);

    @Procedure(name = "P_eliminar_maquina")
    void eliminarMaquina(@Param("cod") Long cod);

    @Procedure(name = "auditar")
    void auditar(@Param("ced") Long id,
                 @Param("tabla") String tabla,
                 @Param("accion") String accion);

}

