package cr.ac.una.gym.Maquina;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.NamedStoredProcedureQueries;
import jakarta.persistence.NamedStoredProcedureQuery;
import jakarta.persistence.StoredProcedureParameter;
import jakarta.persistence.Table;
import jakarta.persistence.ParameterMode;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

@Entity
@Table(name = "GYM_MAQUINAS", schema = "SYSTEM")
@NamedStoredProcedureQueries({
        @NamedStoredProcedureQuery(
                name = "P_actualizar_maquinas",
                procedureName = "P_actualizar_maquinas",
                parameters = {
                        @StoredProcedureParameter(mode = ParameterMode.IN, name = "cod", type = Long.class),
                        @StoredProcedureParameter(mode = ParameterMode.IN, name = "p_descripcion", type = String.class),
                        @StoredProcedureParameter(mode = ParameterMode.IN, name = "p_estado", type = String.class)
                }
        ),
        @NamedStoredProcedureQuery(
                name = "P_eliminar_maquina",
                procedureName = "P_eliminar_maquina",
                parameters = {
                        @StoredProcedureParameter(mode = ParameterMode.IN, name = "cod", type = Long.class)
                }
        )
})
public class GymMaquina {

    @Id
    @Column(name = "ID_MAQUINA", nullable = false)
    private Long id;

    @Size(max = 50)
    @NotNull
    @Column(name = "DESCRIPCION", nullable = false, length = 50)
    private String descripcion;

    @Size(max = 15)
    @Column(name = "ESTADO", length = 15)
    private String estado;

    // Getters y Setters

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }
}
